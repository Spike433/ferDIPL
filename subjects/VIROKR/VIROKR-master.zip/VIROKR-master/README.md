# [Virtualna okruženja](https://www.github.com/studosi-fer/VIROKR)
[<- Stranica predmeta](https://www.fer.unizg.hr/predmet/virokr_a)

[<- Povratak na listu predmeta](https://www.github.com/studosi/FER)
