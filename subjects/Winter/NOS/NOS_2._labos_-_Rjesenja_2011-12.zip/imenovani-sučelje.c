#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

#define STDIN 0
#define STDOUT 1

#define MAX_MSG_LEN 100
#define NUM_OF_QUESTIONS 5
#define BIGGEST_OPERAND 10

char* generate_question() {
  char *q = (char*)malloc(MAX_MSG_LEN * sizeof(char));
  char buf[20] = { 0 };
  char operators[] = "+-*";
  int i, operand;

  memset(q, 0, MAX_MSG_LEN);

  for (i = 2 + rand() % 2; i > 0; i--) {
    sprintf(buf, "%d", rand() % BIGGEST_OPERAND);
    strcat(q, buf);
    if (i != 1) {
      q[strlen(q)] = operators[rand() % strlen(operators)];
      q[strlen(q)] = '\0';
    }
  }

  return q;
}

void conduct_exam(int to_bc, int from_bc) {
  char buf[MAX_MSG_LEN] = { 0 }, answer[MAX_MSG_LEN] = { 0 };
  char *question = NULL;
  int qs = NUM_OF_QUESTIONS;

  srand(time(NULL));

  while (--qs >= 0) {
    question = generate_question();
    sprintf(buf, "%s\n", question);
    write(to_bc, buf, strlen(buf));
    memset(buf, 0, MAX_MSG_LEN);

    printf("%s=", question);
    free(question);
    gets(answer);

    read(from_bc, buf, MAX_MSG_LEN);
    buf[strlen(buf)-1] = '\0';

    if (strcmp(buf, answer) == 0) {
      printf("ISPRAVNO\n");
    } else {
      printf("NEISPRAVNO, točan odgovor je %s\n", buf);
    }
  }
}


int main(int argc, char** argv) {
  int to_bc, to_main;

  mknod("./to_bc", S_IFIFO | 00600, 0);
  mknod("./to_main", S_IFIFO | 00600, 0);

  to_bc = open("./to_bc", O_WRONLY);
  to_main = open("./to_main", O_RDONLY);

  conduct_exam(to_bc, to_main);

  close(to_bc);
  close(to_main);

  return 0;
}
