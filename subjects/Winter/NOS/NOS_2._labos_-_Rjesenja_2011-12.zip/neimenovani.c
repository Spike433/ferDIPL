#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define STDIN 0
#define STDOUT 1

#define READ 0
#define WRITE 1

#define MAX_MSG_LEN 100

#define NUM_OF_QUESTIONS 10
#define BIGGEST_OPERAND 20
#define MAX_NUM_OF_OPERANDS 5

char* generate_question() {
  char *q = (char*)malloc(MAX_MSG_LEN * sizeof(char));
  char buf[20] = { 0 };
  char operators[] = "+-*";
  int i, operand;

  memset(q, 0, MAX_MSG_LEN);

  for (i = 2 + rand() % (MAX_NUM_OF_OPERANDS - 1); i > 0; i--) {
    sprintf(buf, "%d", rand() % BIGGEST_OPERAND);
    strcat(q, buf);
    if (i != 1) {
      q[strlen(q)] = operators[rand() % strlen(operators)];
      q[strlen(q)] = '\0';
    }
  }

  return q;
}

void conduct_exam(int to_bc, int from_bc) {
  char buf[MAX_MSG_LEN] = { 0 }, answer[MAX_MSG_LEN] = { 0 };
  char *question = NULL;
  int qs = NUM_OF_QUESTIONS;

  srand(time(NULL));

  while (--qs >= 0) {
    question = generate_question();
    sprintf(buf, "%s\n", question);
    write(to_bc, buf, strlen(buf));
    memset(buf, 0, MAX_MSG_LEN);

    printf("%s=", question);
    free(question);
    gets(answer);

    read(from_bc, buf, MAX_MSG_LEN);
    buf[strlen(buf)-1] = '\0';

    if (strcmp(buf, answer) == 0) {
      printf("ISPRAVNO\n");
    } else {
      printf("NEISPRAVNO, točan odgovor je %s\n", buf);
    }
  }
}

int main(int argc, char** argv) {
  int to_bc[2], to_main[2];

  pipe(to_bc);
  pipe(to_main);

  switch(fork()) {
  case -1:
    printf("Couldn't fork?\n");
    return 1;

  case 0:
    close(to_bc[WRITE]);
    close(to_main[READ]);

    close(STDIN);
    dup(to_bc[READ]);

    close(STDOUT);
    dup(to_main[WRITE]);

    execl("/usr/bin/bc", "bc", "-q", NULL);

  default:
    close(to_bc[READ]);
    close(to_main[WRITE]);

    conduct_exam(to_bc[WRITE], to_main[READ]);

    close(to_bc[WRITE]);
    close(to_main[READ]);

    wait(NULL);
  }

  return 0;
}
