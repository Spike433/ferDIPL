#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

#define STDIN 0
#define STDOUT 1

int main(int argc, char** argv) {
  int to_bc, to_main;

  mknod("./to_bc", S_IFIFO | 00600, 0);
  mknod("./to_main", S_IFIFO | 00600, 0);

  to_bc = open("./to_bc", O_RDONLY);
  to_main = open("./to_main", O_WRONLY);

  close(STDIN);
  dup(to_bc);

  close(STDOUT);
  dup(to_main);

  execl("/usr/bin/bc", "bc", "-q", NULL);

  return 0;
}
