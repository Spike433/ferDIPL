newWindow.py se pokrece u pythonu 2.7, potreban je tkinter i pycrypto.

Nije napravljena logika za izradu pečata(ne radi, ali je prozor napravljen), ali nebi trebao biti problem to dodati pošto su omotnica i potpis napravljeni. Princip je isti, samo se copy paste-a glavnina koda. (bez toga sam dobio 9/10 bodova)

Problem je kod "Odaberi" opcije da se ne promijeni na GUI-u ime nove datoteke koja je odabrana. Valjda se da sredit, al meni se nije dalo, niti to itko skuzi na predaji labosa.

ja sam sve iz foldera "py fajlovi" i "txt" stavio u folder na ubuntuu "home/NOS3" i sve onda radi po spagici :)

srećno!
