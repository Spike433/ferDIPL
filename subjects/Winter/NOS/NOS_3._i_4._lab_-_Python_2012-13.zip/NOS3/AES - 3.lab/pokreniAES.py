import pyAES
 
def intToList(number):
    #konvertiraj 16 bajtni broj u listu 16 elemenata
    return [(number >> 120) & 0xff, (number >> 112) & 0xff,
            (number >> 104) & 0xff, (number >> 96)  & 0xff,
            (number >> 88)  & 0xff, (number >> 80)  & 0xff,
            (number >> 72)  & 0xff, (number >> 64)  & 0xff,
            (number >> 56)  & 0xff, (number >> 48)  & 0xff,
            (number >> 40)  & 0xff, (number >> 32)  & 0xff,
            (number >> 24)  & 0xff, (number >> 16)  & 0xff,
            (number >> 8)   & 0xff,  number & 0xff]
 
def intToText(hexNumber):
    #konvertiraj 16 bajtni u broj u string od 16 znakova (charova)
    return "".join(chr(e) for e in intToList(hexNumber))
     
def provjeriTestniVektor1(mode, velicinaKljuca, kljuc, obicnitekst, sifriranitekst, iv = None):
    #provjeri vektore za kriptiranje samo jednog bloka
    uspjeh = True
    obj = pyAES.AES(mode)
    obj.prosiriKljuc(velicinaKljuca, kljuc, iv)
    for i, (p, c) in enumerate(zip(obicnitekst, sifriranitekst)):
        p_text = intToText(p)
        c_text = intToList(c)
        code = "{0:3s}-{1:3s}".format(mode[5:], velicinaKljuca[5:])
        try:
            assert obj.kriptiraj(p_text) == c_text
        except AssertionError:
            print(code, "kriptiranja #{:d} neuspjelo".format(i))
            uspjeh = False
        try:
            assert obj.dekriptiraj(c_text) == p_text
        except AssertionError:
            print(code, "dekripcija #{:d} neuspjela".format(i))
            uspjeh = False
    if uspjeh:
        print(code, "enkripcija/dekripcija OK")
    return uspjeh
         
def provjeriTestniVektor2(mode, velicinaKljuca, obicnitekst, kljuc1, kljuc2, iv1 = None, iv2 = None):
    obj1 = pyAES.AES(mode, "PKCS5Padding")
    obj1.prosiriKljuc(velicinaKljuca, kljuc1, iv1)
    obj2 = pyAES.AES(mode, "PKCS5Padding")
    obj2.prosiriKljuc(velicinaKljuca, kljuc2, iv2)
    sifriranitekst1 = obj1.kriptiraj(obicnitekst)
    sifriranitekst2 = obj2.kriptiraj(obicnitekst)
    obicnitekst1 = obj1.dekriptiraj(sifriranitekst1)
    obicnitekst2 = obj2.dekriptiraj(sifriranitekst2)
    code = "{0:3s}-{1:3s}".format(mode[5:], velicinaKljuca[5:])
    try:
        assert obicnitekst1 == obicnitekst and obicnitekst2 == obicnitekst
    except AssertionError:
        print("Viseblokovna", code, "enkripcija dekripcija neuspjela")
        return False
    print("Viseblokovna", code, "enkripcija dekripcija OK")
    return True
 
#===========================================================================
     
# testiraj Vektore iz NIST SP800-38A odjeljak F.1.1 i F.1.2
def ECB_128_NOPAD():
    kljuc = 0x2b7e151628aed2a6abf7158809cf4f3c
    obicnitekst =  [0x6bc1bee22e409f96e93d7e117393172a,
                  0xae2d8a571e03ac9c9eb76fac45af8e51,
                  0x30c81c46a35ce411e5fbc1191a0a52ef,
                  0xf69f2445df4f9b17ad2b417be66c3710]
    sifriranitekst = [0x3ad77bb40d7a3660a89ecaf32466ef97,
                  0xf5d3d58503b9699de785895a96fdbaaf,
                  0x43b1cd7f598ece23881b00e3ed030688,
                  0x7b0c785e27e8ad3f8223207104725dd4]
    return provjeriTestniVektor1("MODE_ECB", "SIZE_128", kljuc, obicnitekst, sifriranitekst)
 
# testiraj Vektore iz NIST SP800-38A odjeljak F.1.3 i F.1.4
def ECB_192_NOPAD():
    kljuc = 0x8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b
    obicnitekst =  [0x6bc1bee22e409f96e93d7e117393172a,
                  0xae2d8a571e03ac9c9eb76fac45af8e51,
                  0x30c81c46a35ce411e5fbc1191a0a52ef,
                  0xf69f2445df4f9b17ad2b417be66c3710]
    sifriranitekst = [0xbd334f1d6e45f25ff712a214571fa5cc,
                  0x974104846d0ad3ad7734ecb3ecee4eef,
                  0xef7afd2270e2e60adce0ba2face6444e,
                  0x9a4b41ba738d6c72fb16691603c18e0e]
    return provjeriTestniVektor1("MODE_ECB", "SIZE_192", kljuc, obicnitekst, sifriranitekst)
 
# testiraj Vektore iz NIST SP800-38A odjeljak F.1.5 i F.1.6
def ECB_256_NOPAD():
    kljuc = 0x603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4
    obicnitekst =  [0x6bc1bee22e409f96e93d7e117393172a,
                  0xae2d8a571e03ac9c9eb76fac45af8e51,
                  0x30c81c46a35ce411e5fbc1191a0a52ef,
                  0xf69f2445df4f9b17ad2b417be66c3710]
    sifriranitekst = [0xf3eed1bdb5d2a03c064b5a7e3db181f8,
                  0x591ccb10d410ed26dc5ba74a31362870,
                  0xb6ed21b99ca6f4f9f153e7b1beafed1d,
                  0x23304b7a39f9f3ff067d8d8f9e24ecc7]
    return provjeriTestniVektor1("MODE_ECB", "SIZE_256", kljuc, obicnitekst, sifriranitekst)
 
# testiraj Vektore iz NIST SP800-38A odjeljak F.2.1 i F.2.2
def CBC_128_NOPAD():
    kljuc = 0x2b7e151628aed2a6abf7158809cf4f3c
    iv = 0x000102030405060708090a0b0c0d0e0f
    obicnitekst =  [0x6bc1bee22e409f96e93d7e117393172a,
                   0xae2d8a571e03ac9c9eb76fac45af8e51,
                   0x30c81c46a35ce411e5fbc1191a0a52ef,
                   0xf69f2445df4f9b17ad2b417be66c3710]
    sifriranitekst = [0x7649abac8119b246cee98e9b12e9197d,
                  0x5086cb9b507219ee95db113a917678b2,
                  0x73bed6b8e3c1743b7116e69e22229516,
                  0x3ff1caa1681fac09120eca307586e1a7]
    return provjeriTestniVektor1("MODE_CBC", "SIZE_128", kljuc, obicnitekst, sifriranitekst, iv)
 
# testiraj Vektore iz NIST SP800-38A odjeljak F.2.3 i F.2.4
def CBC_192_NOPAD():
    kljuc = 0x8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b
    iv = 0x000102030405060708090a0b0c0d0e0f
    obicnitekst =  [0x6bc1bee22e409f96e93d7e117393172a,
                  0xae2d8a571e03ac9c9eb76fac45af8e51,
                  0x30c81c46a35ce411e5fbc1191a0a52ef,
                  0xf69f2445df4f9b17ad2b417be66c3710]
    sifriranitekst = [0x4f021db243bc633d7178183a9fa071e8,
                  0xb4d9ada9ad7dedf4e5e738763f69145a,
                  0x571b242012fb7ae07fa9baac3df102e0,
                  0x08b0e27988598881d920a9e64f5615cd]
    return provjeriTestniVektor1("MODE_CBC", "SIZE_192", kljuc, obicnitekst, sifriranitekst, iv)
 
# testiraj Vektore iz NIST SP800-38A odjeljak F.2.5 i F.2.6
def CBC_256_NOPAD():
    kljuc = 0x603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4
    iv = 0x000102030405060708090a0b0c0d0e0f
    obicnitekst=  [0x6bc1bee22e409f96e93d7e117393172a,
                 0xae2d8a571e03ac9c9eb76fac45af8e51,
                 0x30c81c46a35ce411e5fbc1191a0a52ef,
                 0xf69f2445df4f9b17ad2b417be66c3710]
    sifriranitekst = [0xf58c4c04d6e5f1ba779eabfb5f7bfbd6,
                  0x9cfc4e967edb808d679f777bc6702c7d,
                  0x39f23369a9d9bacfa530e26304231461,
                  0xb2eb05e2c39be9fcda6c19078c6a9d1b]
    return provjeriTestniVektor1("MODE_CBC", "SIZE_256", kljuc, obicnitekst, sifriranitekst, iv)
# testiraj Vektore iz NIST SP800-38A odjeljak F.4.1 i F.4.2
def OFB_128_NOPAD():
    kljuc = 0x2b7e151628aed2a6abf7158809cf4f3c
    iv = 0x000102030405060708090a0b0c0d0e0f
    obicnitekst = [0x6bc1bee22e409f96e93d7e117393172a,
                 0xae2d8a571e03ac9c9eb76fac45af8e51,
                 0x30c81c46a35ce411e5fbc1191a0a52ef,
                 0xf69f2445df4f9b17ad2b417be66c3710]
    sifriranitekst = [0x3b3fd92eb72dad20333449f8e83cfb4a,
                  0x7789508d16918f03f53c52dac54ed825,
                  0x9740051e9c5fecf64344f7a82260edcc,
                  0x304c6528f659c77866a510d9c1d6ae5e]
    return provjeriTestniVektor1("MODE_OFB", "SIZE_128", kljuc, obicnitekst, sifriranitekst, iv)
# testiraj Vektore iz NIST SP800-38A odjeljak F.4.3 i F.4.4
def OFB_192_NOPAD():
    kljuc = 0x8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b
    iv = 0X000102030405060708090a0b0c0d0e0f
    obicnitekst = [0x6bc1bee22e409f96e93d7e117393172a,
                 0xae2d8a571e03ac9c9eb76fac45af8e51,
                 0x30c81c46a35ce411e5fbc1191a0a52ef,
                 0xf69f2445df4f9b17ad2b417be66c3710]
    sifriranitekst = [0xcdc80d6fddf18cab34c25909c99a4174,
                  0xfcc28b8d4c63837c09e81700c1100401,
                  0x8d9a9aeac0f6596f559c6d4daf59a5f2,
                  0x6d9f200857ca6c3e9cac524bd9acc92a]
    return provjeriTestniVektor1("MODE_OFB", "SIZE_192", kljuc, obicnitekst, sifriranitekst, iv)
# testiraj Vektore iz NIST SP800-38A odjeljak F.4.4 i F.4.6
def OFB_256_NOPAD():
    kljuc = 0x603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4
    iv = 0x000102030405060708090a0b0c0d0e0f
    obicnitekst = [0x6bc1bee22e409f96e93d7e117393172a,
                 0xae2d8a571e03ac9c9eb76fac45af8e51,
                 0x30c81c46a35ce411e5fbc1191a0a52ef,
                 0xf69f2445df4f9b17ad2b417be66c3710]
    sifriranitekst = [0xdc7e84bfda79164b7ecd8486985d3860,
                  0x4febdc6740d20b3ac88f6ad82a4fb08d,
                  0x71ab47a086e86eedf39d1c5bba97c408,
                  0x0126141d67f37be8538f5a8be740e484]
    return provjeriTestniVektor1("MODE_OFB", "SIZE_256", kljuc, obicnitekst, sifriranitekst, iv)
#===========================================================================
 
# dvje više blokovne enkripcije u ECB modu s  128-bitnim kljucem
def ECB_128_PKCS5():
    obicnitekst = "Pero i Marko setali su njivom Pere Debilka"
    kljuc1 = 0x000102030405060708090a0b0c0d0e0f
    kljuc2 = 0xffeeddccbbaa99887766554433221100
    return provjeriTestniVektor2("MODE_ECB", "SIZE_128", obicnitekst, kljuc1, kljuc2)
     
# dvje više blokovne enkripcije u ECB modu s  192-bitnim kljucem           
def ECB_192_PKCS5():
    obicnitekst = "Pero i Marko setali su njivom Pere Debilka"
    kljuc1 = 0x000102030405060708090a0b0c0d0e0f1011121314151617
    kljuc2 = 0x1716151413121110ffeeddccbbaa99887766554433221100
    return provjeriTestniVektor2("MODE_ECB", "SIZE_192", obicnitekst, kljuc1, kljuc2)
     
# dvje više blokovne enkripcije u ECB modu s  256-bitnim kljucem               
def ECB_256_PKCS5():
    obicnitekst = "Pero i Marko setali su njivom Pere Debilka"
    kljuc1 = 0x000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f
    kljuc2 = 0x1f1e1d1c1b1a19181716151413121110ffeeddccbbaa99887766554433221100
    return provjeriTestniVektor2("MODE_ECB", "SIZE_256", obicnitekst, kljuc1, kljuc2)
     
# dvje više blokovne enkripcije u CBC modu s  128-bitnim kljucem               
def CBC_128_PKCS5():
    obicnitekst = "Pero i Marko setali su njivom Pere Debilka"
    kljuc1 = 0x000102030405060708090a0b0c0d0e0f
    kljuc2 = 0xffeeddccbbaa99887766554433221100
    iv1 = 0x0123cdef456789ab0123cdef456789ab
    iv2 = 0xab0123cdef456789ab0123cdef456789
    return provjeriTestniVektor2("MODE_CBC", "SIZE_128", obicnitekst, kljuc1, kljuc2, iv1, iv2)
     
# dvje više blokovne enkripcije u CBC modu s  192-bitnim kljucem               
def CBC_192_PKCS5():
    obicnitekst = "Pero i Marko setali su njivom Pere Debilka"
    kljuc1 = 0x000102030405060708090a0b0c0d0e0f1011121314151617
    kljuc2 = 0x1716151413121110ffeeddccbbaa99887766554433221100
    iv1 = 0x0123cdef456789ab0123cdef456789ab
    iv2 = 0xab0123cdef456789ab0123cdef456789
    return provjeriTestniVektor2("MODE_CBC", "SIZE_192", obicnitekst, kljuc1, kljuc2, iv1, iv2)
     
# dvje više blokovne enkripcije u CBC modu s  256-bitnim kljucem
def CBC_256_PKCS5():
    obicnitekst = "Pero i Marko setali su njivom Pere Debilka"
    kljuc1 = 0x000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f
    kljuc2 = 0x1f1e1d1c1b1a19181716151413121110ffeeddccbbaa99887766554433221100
    iv1 = 0x0123cdef456789ab0123cdef456789ab
    iv2 = 0xab0123cdef456789ab0123cdef456789
    return provjeriTestniVektor2("MODE_CBC", "SIZE_256", obicnitekst, kljuc1, kljuc2, iv1, iv2)

# dvje više blokovne enkripcije u OFB modu s 128-bitnim kljucem               
def OFB_128_PKCS5():
    obicnitekst = "Pero i Marko setali su njivom Pere Debilka"
    kljuc1 = 0x000102030405060708090a0b0c0d0e0f
    kljuc2 = 0xffeeddccbbaa99887766554433221100
    iv1 = 0x0123cdef456789ab0123cdef456789ab
    iv2 = 0xab0123cdef456789ab0123cdef456789
    return provjeriTestniVektor2("MODE_OFB", "SIZE_128", obicnitekst, kljuc1, kljuc2, iv1, iv2)
     
# dvje više blokovne enkripcije u OFB modu s 192-bitnim kljucem               
def OFB_192_PKCS5():
    obicnitekst = "Pero i Marko setali su njivom Pere Debilka"
    kljuc1 = 0x000102030405060708090a0b0c0d0e0f1011121314151617
    kljuc2 = 0x1716151413121110ffeeddccbbaa99887766554433221100
    iv1 = 0x0123cdef456789ab0123cdef456789ab
    iv2 = 0xab0123cdef456789ab0123cdef456789
    return provjeriTestniVektor2("MODE_OFB", "SIZE_192", obicnitekst, kljuc1, kljuc2, iv1, iv2)
     
# dvje više blokovne enkripcije u OFB modu s 256-bitnim kljucem
def OFB_256_PKCS5():
    obicnitekst = "Pero i Marko setali su njivom Pere Debilka"
    kljuc1 = 0x000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f
    kljuc2 = 0x1f1e1d1c1b1a19181716151413121110ffeeddccbbaa99887766554433221100
    iv1 = 0x0123cdef456789ab0123cdef456789ab
    iv2 = 0xab0123cdef456789ab0123cdef456789
    return provjeriTestniVektor2("MODE_OFB", "SIZE_256", obicnitekst, kljuc1, kljuc2, iv1, iv2)
 
def main():
    # pokreni testiranja vektora
    uspjeh = True
    for pad in ["NOPAD", "PKCS5"]:
        for mode in ["ECB", "OFB"]:
            for size in ["128", "192", "256"]:
		#print("mode %s i size: %s", mode, size)
                testVector = mode + "_" + size + "_" + pad + "()"
		#print testVector
                uspjeh = uspjeh & eval(testVector)
    if uspjeh:
        print("Svi testovi uspješni!")
     
if __name__ == '__main__':
    main()
