potreban je python 3.3.

U biti je ovo skinuto s neta: 

http://jhafranco.com/2012/01/16/aes-implementation-in-python/

i dodan je OFB nacin kriptiranja, i oni blokovi za provjeru AES-a.
