from Crypto.PublicKey import RSA
import pickle
from Crypto import Random
from Tkinter import *
from tkFileDialog import *
import os
from base64 import b64encode, b64decode

class rsaController:
    def __init__(self):
        self.public_path='rsa_public.txt'
        self.private_path='rsa_private.txt'
        self.keysize = 1024

    def odaberi_privatni_kljuc(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.private_path = choosen
        #os.system('gedit '+self.choosen)
    
    def pregledaj_privatni_kljuc(self):
        os.system('gedit '+ self.private_path)

    def odaberi_javni_kljuc(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.public_path = choosen

        #os.system('gedit '+self.choosen)
            
    def pregledaj_javni_kljuc(self):
        os.system('gedit '+ self.public_path)
        
    def generiraj(self, keySize):
        self.keysize=keySize
        random_generator = Random.new().read
        kljuc = RSA.generate(keySize, random_generator) #generiram par kljuceva
        javni = kljuc.publickey() #javni kljuc
        kljuc = kljuc.exportKey('DER')
        javni = javni.exportKey('DER')
        temp = self.ByteToHex(javni)
        temp = self.HexToByte(temp)
        if ( temp == javni):
            print "isti su!!!"


        
	kljuc = self.ByteToHex(kljuc)
	javni = self.ByteToHex(javni)

	#Zapis javnog:
	file = open(self.public_path,'w')
	file.write('---BEGIN OS2 CRYPTO DATA---\n')
        file.write('Description:\n    Public key\n\n')
        file.write('Method:\n    RSA\n\n')
        file.write('File name:\n    ')
        file.write(self.public_path)
        file.write('\n\nKey length:\n    '+(str(hex(self.keysize))).replace('0x',''))
        file.write('\n\nSecret key:\n    ')
        i=1
        for c in javni:
            if i == 61:
                file.write('\n    ')
                i=1 
            file.write(c)
            i+=1           
        file.write('\n\n---END OS2 CRYPTO DATA---')

        #Zapis privatnog
        file = open(self.private_path,'w')
	file.write('---BEGIN OS2 CRYPTO DATA---\n')
        file.write('Description:\n    Private key\n\n')
        file.write('Method:\n    RSA\n\n')
        file.write('File name:\n    ')
        file.write(self.private_path)
        file.write('\n\nKey length:\n    '+(str(hex(keySize))).replace('0x',''))
        file.write('\n\nSecret key:\n    ')
        i=1
        for c in kljuc:
            if i == 61:
                file.write('\n    ')
                i=1 
            file.write(c)
            i+=1           
        file.write('\n\n---END OS2 CRYPTO DATA---')

    def ByteToHex(self, byteStr ):
        return ''.join( [ "%02X" % ord( x ) for x in byteStr ] ).strip()
    def HexToByte(self, hexStr ):    
        bytes = []
        hexStr = ''.join( hexStr.split(" ") )
        for i in range(0, len(hexStr), 2):
            bytes.append( chr( int (hexStr[i:i+2], 16 ) ) )
        return ''.join( bytes )
