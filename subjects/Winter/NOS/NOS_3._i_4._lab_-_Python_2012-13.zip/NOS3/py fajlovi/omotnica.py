from Tkinter import *
from tkFileDialog import *
from Crypto.Cipher import  AES as Aes
from Crypto.PublicKey import RSA
import os
from base64 import b64encode, b64decode
from Crypto.Cipher import PKCS1_OAEP



class omotnica:
    def __init__(self):
        self.ulaz_path = 'ulaz.txt'
        self.rsa_b_javni = 'rsa_b_javni.txt'
        self.rsa_b_tajni = 'rsa_b_tajni.txt'
        self.izlaz_path = 'izlaz.txt'
        self.omotnica_path = 'omotnica.txt'

#envelope data, envelope crypt key
    def generiraj(self):
        data = self.ucitaj_ulaz()
        aesKey = os.urandom(16)
        AESencryptor = Aes.new(aesKey)
        if len(data)%16 !=0 :
            data += ' ' * (16 - len(data) % 16)
        encoded = AESencryptor.encrypt(data)
        encoded = b64encode(encoded) #poruka kriptirana s AES-om
        
        rsaPublicKey = self.ucitaj_javni()
        rsaPublicKeyLength = self.ucitaj_javni_duljina()
        if len(rsaPublicKeyLength)==3:
            rsaPublicKeyLength = '0' + rsaPublicKeyLength
        rsaPublicKey = self.HexToByte(rsaPublicKey)
        RSAEncryptor = RSA.importKey(rsaPublicKey)
        encryptor = PKCS1_OAEP.new(RSAEncryptor)
        aesEncrypted = encryptor.encrypt(aesKey)
        aesEncrypted = self.ByteToHex(aesEncrypted) #kljuc kriptiran s RSA

        # zapisivanje
        file = open(self.omotnica_path, 'w')
        file.write('---BEGIN OS2 CRYPTO DATA---\n')
        file.write('Description:\n    Envelope\n\n')
        file.write('File name:\n    ')
        file.write(self.omotnica_path)
        file.write('\nMethod:\n    AES\n    RSA\n\n')
        file.write('Key length:\n    ')
        file.write('0010\n    ')
        file.write(rsaPublicKeyLength)
        file.write('\n\nEnvelope data:\n    ')
        i=1
        for c in encoded:
            if i == 61:
                file.write('\n    ')
                i=1 
            file.write(c)
            i+=1
        file.write('\n\nEnvelope crypt key:\n    ')
        i=1
        for c in aesEncrypted:
            if i == 61:
                file.write('\n    ')
                i=1 
            file.write(c)
            i+=1 
        file.write('\n\n---END OS2 CRYPTO DATA---')

    def otvori(self):
        envelopeData = b64decode(self.ucitaj_envelope_data())
        cryptKey = self.HexToByte(self.ucitaj_crypt_key())        
        privateKey = self.HexToByte(self.ucitaj_private())
        
        RSAKey = RSA.importKey(privateKey)
        #aesKey = RSADecryptor.decrypt(cryptKey) #dekriptiran AES kljuc
        cipher = PKCS1_OAEP.new(RSAKey)
        aesKey = cipher.decrypt(cryptKey)        
        AESdecryptor = Aes.new(aesKey)
        data = AESdecryptor.decrypt(envelopeData) #dekriptirana poruka
        print data
        
        # zapisivanje data-e
        file = open(self.izlaz_path, 'w')
        file.write('---BEGIN OS2 CRYPTO DATA---\n')
        file.write('Description:\n    Decrypted Envelope\n\n')
        file.write('File name:\n    ')
        file.write(self.izlaz_path)
        file.write('\n\nMethod:\n    AES\n    RSA\n\n')
        file.write('Data:\n    ')
        i=1
        for c in data:
            if i == 61:
                file.write('\n    ')
                i=1 
            file.write(c)
            i+=1
        file.write('\n\n---END OS2 CRYPTO DATA---')
        

        
        

    def ucitaj_private(self):
        file = open(self.rsa_b_tajni)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Secret key:\n':
                found = True
        return ulaz
    
    def ucitaj_envelope_data(self):
        file = open(self.omotnica_path)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Envelope data:\n':
                found = True
        return ulaz
    def ucitaj_crypt_key(self):
        file = open(self.omotnica_path)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Envelope crypt key:\n':
                found = True
        return ulaz


    def ucitaj_javni(self):
        file = open(self.rsa_b_javni)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Secret key:\n':
                found = True
        return ulaz
    def ucitaj_javni_duljina(self):
        file = open(self.rsa_b_javni)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Key length:\n':
                found = True
        return ulaz

    def ucitaj_ulaz(self):
        file = open(self.ulaz_path)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Data:\n':
                found = True
        return ulaz

    

    def pregledaj_javni(self):
        os.system('gedit '+ self.rsa_b_javni)
    def odaberi_javni(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.rsa_b_javni = choosen
    def pregledaj_ulaz(self):
        os.system('gedit '+ self.ulaz_path)
    def odaberi_ulaz(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.ulaz_path = choosen
    def pregledaj_omotnicu(self):
        os.system('gedit '+ self.omotnica_path)
    def odaberi_omotnicu(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.omotnica_path = choosen
    def pregledaj_izlaz(self):
        os.system('gedit '+ self.izlaz_path)
    def odaberi_izlaz(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.izlaz_path = choosen
                               
    def odaberi_tajni(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.rsa_b_tajni = choosen
    def pregledaj_tajni(self):
        os.system('gedit '+ self.rsa_b_tajni)

    def odaberi_izlaz(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.izlaz_path = choosen
    def pregledaj_izlaz(self):
        os.system('gedit '+ self.izlaz_path)

    def ByteToHex(self, byteStr ):
        return ''.join( [ "%02X" % ord( x ) for x in byteStr ] ).strip()
    def HexToByte(self, hexStr ):    
        bytes = []
        hexStr = ''.join( hexStr.split(" ") )
        for i in range(0, len(hexStr), 2):
            bytes.append( chr( int (hexStr[i:i+2], 16 ) ) )
        return ''.join( bytes )

    
