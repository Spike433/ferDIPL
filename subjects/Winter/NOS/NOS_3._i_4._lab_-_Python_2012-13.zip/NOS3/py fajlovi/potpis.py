# -*- coding: utf-8 -*-
import Crypto.Hash.MD5 as MD5
import Crypto.PublicKey.RSA as RSA
import os
from base64 import b64encode, b64decode
from hashlib import sha1
import hashlib

class potpis:
    def __init__(self):
        self.ulaz_path = 'ulaz.txt'
        self.tajni_path = 'rsa_a_tajni.txt'
        self.potpis_path = 'potpis.txt'
        self.javni_path = 'rsa_a_javni.txt'


    def generiraj(self):
        data = self.ucitaj_ulaz()
        secretKey = self.HexToByte(self.ucitaj_tajni())
        secretKeyLength = self.ucitaj_tajni_duljina()
        m = hashlib.sha1()
        m.update(data)
        sazetak = m.digest()
        #sazetak
        RSAEncryptor = RSA.importKey(secretKey)
        potpis = RSAEncryptor.sign(sazetak, '')[0]
        temp=potpis #long number
        
        #zapisivanje
        data = b64encode(data)

        potpis = self.ByteToHex(str(potpis))        
        #potpis = long(self.HexToByte(potpis))

        # zapisivanje
        file = open(self.potpis_path, 'w')
        file.write('---BEGIN OS2 CRYPTO DATA---\n')
        file.write('Description:\n    Signature\n\n')
        file.write('File name:\n    ')
        file.write(self.potpis_path)
        file.write('\nMethod:\n    SHA-1\n    RSA\n\n')
        file.write('Key length:\n    ')
        file.write('00A0\n    ')
        file.write(secretKeyLength)
        file.write('\n\nData:\n    ')
        i=1
        for c in data:
            if i == 61:
                print c
                file.write('\n    ')
                i=1 
            file.write(c)
            i+=1
        file.write('\n\nSignature:\n    ')
        i=1
        for c in potpis:
            if i == 61:
                file.write('\n    ')
                i=1 
            file.write(c)
            i+=1 
        file.write('\n\n---END OS2 CRYPTO DATA---')

    def provjeri(self):
        data = self.ucitaj_data()
        data = b64decode(data)
        key = self.ucitaj_javni()
        key = self.HexToByte(key)
        potpis = self.ucitaj_potpis()
        potpis = long(self.HexToByte(potpis))
        potpis = (potpis, '')
        #sazetak 
        m = hashlib.sha1()
        m.update(data)
        sazetak = m.digest()

        RSAEncryptor = RSA.importKey(key)
        if RSAEncryptor.verify(sazetak, potpis):
            print "Poruka je autenticna!"
        else:
            print "Integritet i autenticnost poruke su naruseni!!!"
        return RSAEncryptor.verify(sazetak, potpis)

    def ucitaj_data(self):
        file = open(self.potpis_path)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Data:\n':
                found = True
        return ulaz
    
    def ucitaj_potpis(self):
        file = open(self.potpis_path)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Signature:\n':
                found = True
        return ulaz
    
    def ucitaj_tajni(self):
        file = open(self.tajni_path)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Secret key:\n':
                found = True
        return ulaz
    
    def ucitaj_tajni_duljina(self):
        file = open(self.tajni_path)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Key length:\n':
                found = True
        return ulaz
    
    def ucitaj_javni(self):
        file = open(self.javni_path)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Secret key:\n':
                found = True
        return ulaz

    def ucitaj_ulaz(self):
        file = open(self.ulaz_path)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Data:\n':
                found = True
        return ulaz




    def pregledaj_javni(self):
        os.system('gedit '+ self.javni_path)
    def odaberi_javni(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.javni_path = choosen
    def pregledaj_ulaz(self):
        os.system('gedit '+ self.ulaz_path)
    def odaberi_ulaz(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.ulaz_path = choosen
    def pregledaj_potpis(self):
        os.system('gedit '+ self.potpis_path)
    def odaberi_potpis(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.potpis_path = choosen
    def pregledaj_tajni(self):
        os.system('gedit '+ self.tajni_path)
    def odaberi_tajni(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.tajni_path = choosen

    def ByteToHex(self, byteStr ):
        return ''.join( [ "%02X" % ord( x ) for x in byteStr ] ).strip()
    def HexToByte(self, hexStr ):    
        bytes = []
        hexStr = ''.join( hexStr.split(" ") )
        for i in range(0, len(hexStr), 2):
            bytes.append( chr( int (hexStr[i:i+2], 16 ) ) )
        return ''.join( bytes )
    def toStr(self, s):
        return s and chr(atoi(s[:2], base=16)) + toStr(s[2:]) or ''
    def toHex(self, x):
        return "".join([hex(ord(c))[2:].zfill(2) for c in x])
