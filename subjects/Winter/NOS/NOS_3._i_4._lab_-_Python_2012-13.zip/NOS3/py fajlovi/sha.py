import Crypto.PublicKey.RSA as RSA
from hashlib import sha1
import hashlib
import os
class sha:
    def __init__(self):
        self.ulaz_path = 'ulaz.txt'
        self.izlaz_path = 'sazetak.txt'







    def generiraj(self):
        data = self.ucitaj_ulaz()
        m = hashlib.sha1()
        m.update(data)
        sazetak = m.digest()
        sazetak = self.ByteToHex(sazetak)
        file = open(self.izlaz_path, 'w')
        file.write('---BEGIN OS2 CRYPTO DATA---\n')
        file.write('Description:\n    Digest\n\n')
        file.write('File name:\n    ')
        file.write(self.izlaz_path)
        file.write('\nMethod:\n    SHA-1\n\n')
        file.write('Key length:\n    ')
        file.write('00A0\n')
        file.write('\nDigest:\n    ')
        i=1
        for c in sazetak:
            if i == 61:
                file.write('\n    ')
                i=1 
            file.write(c)
            i+=1 
        file.write('\n\n---END OS2 CRYPTO DATA---')
        return sazetak


    def ucitaj_ulaz(self):
        file = open(self.ulaz_path)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Data:\n':
                found = True
        return ulaz
    
    def pregledaj_ulaz(self):
        os.system('gedit '+ self.ulaz_path)
    def odaberi_ulaz(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.ulaz_path = choosen
    def pregledaj_izlaz(self):
        os.system('gedit '+ self.izlaz_path)
    def odaberi_izlaz(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.izlaz_path = choosen
    def ByteToHex(self, byteStr ):
        return ''.join( [ "%02X" % ord( x ) for x in byteStr ] ).strip()
    def HexToByte(self, hexStr ):    
        bytes = []
        hexStr = ''.join( hexStr.split(" ") )
        for i in range(0, len(hexStr), 2):
            bytes.append( chr( int (hexStr[i:i+2], 16 ) ) )
        return ''.join( bytes )
