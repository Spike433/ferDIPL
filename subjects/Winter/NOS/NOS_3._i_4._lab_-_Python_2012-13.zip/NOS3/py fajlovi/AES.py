from Tkinter import *
from tkFileDialog import *
import os
from Crypto.Cipher import AES as Aes
from base64 import b64encode, b64decode

class AES:
    def __init__(self):
        self.kljuc_path = 'aes_kljuc.txt'
        self.ulaz_path = 'aes_ulaz.txt'
        self.izlaz_path = 'aes_izlaz.txt'
        self.key = os.urandom(16)
        self.keySize = 16
    def get_kljuc_path(self):
        return self.kljuc_path
            
    def odaberi_kljuc(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.kljuc_path = choosen
        #os.system('gedit '+self.choosen)
    
    def pregledaj_kljuc(self):
        os.system('gedit '+ self.kljuc_path)

    def odaberi_ulaz(self):
        choosen = askopenfilename(initialdir='~/NOS3/')
        self.ulaz_path = choosen

        #os.system('gedit '+self.choosen)
            
    def pregledaj_ulaz(self):
        os.system('gedit '+ self.ulaz_path)
                  
    def odaberi_izlaz(self):
        self.izlaz_path = askopenfilename(initialdir='~/NOS3/')
    
    def pregledaj_izlaz(self):
        os.system('gedit '+ self.izlaz_path)

    def kriptdekript(self, val):
        if (1==val): self.kriptiraj()
        else: self.dekriptiraj()
    def kriptiraj(self):
        print "kriptiram"
        self.update_kljuc()
        data = self.update_ulaz() #data to be encrypted
        encryptor = Aes.new(self.key)
        #data = b64decode(data)
        print len(data)
        print self.keySize
        if len(data)%self.keySize !=0 :
            data += ' ' * (self.keySize - len(data) % self.keySize)
        print len(data)
        encoded = encryptor.encrypt(data)
        #encoded = b64encode(encoded)

        #zapisivanje u fajl
        file = open(self.izlaz_path, 'w')
        file.write('---BEGIN OS2 CRYPTO DATA---\n')
        file.write('Description:\n    Crypted file\n\n')
        file.write('Method:\n    AES\n\n')
        file.write('File name:\n    ')
        file.write(self.izlaz_path)
        file.write('\n\nData:\n    ')
        i=1
        for c in encoded:
            if i == 61:
                file.write('\n    ')
                i=1 
            file.write(c)
            i+=1        
        file.write('\n\n---END OS2 CRYPTO DATA---')

    def dekriptiraj(self):
        print "dekriptiram"
        self.update_kljuc()
        data = self.update_ulaz() #data to be decrypted
        encryptor = Aes.new(self.key)
        #data = b64decode(data)
        #data += ' ' * (self.keySize/8 - len(data) % self.keySize)
        decoded = encryptor.decrypt(data)
        decoded = decoded.strip()
        print "dekriptirano u b64:" + decoded
        data = b64decode(decoded)
        print "b64dekodirano: " + data
        #zapisivanje u fajl
        file = open(self.izlaz_path, 'w')
        file.write('---BEGIN OS2 CRYPTO DATA---\n')
        file.write('Description:\n    Decrypted file\n\n')
        file.write('Method:\n    AES\n\n')
        file.write('File name:\n    ')
        file.write(self.izlaz_path)
        file.write('\n\nData:\n    ')
        i=1
        for c in decoded:
            if i == 61:
                file.write('\n    ')
                i=1 
            file.write(c)
            i+=1        
        file.write('\n\n---END OS2 CRYPTO DATA---')

    def update_kljuc(self):
        file = open(self.kljuc_path)
        #print "updejtam kljuc"
        found = False
        for line in file:
            if found:
                self.key = line.strip()
                self.key = self.HexToByte(self.key)
                found = False
            if line=='Secret key:\n':
                found = True
        found = False
        for line in file:
            if found:
                self.keySize = int(line.strip(), 16)
                found = False
            if line == 'Key length:\n':
                found = True
        #print self.key
    def update_ulaz(self):
        file = open(self.ulaz_path)
        ulaz =''
        found=False
        for line in file:
            if found and line!='\n':
                ulaz += line.strip()
            if found and line =='\n':
                found = False
            if line == 'Data:\n':
                found = True
        return ulaz
        
    def generiraj_kljuc(self, keySize):
        self.key = os.urandom(keySize/8)
        print "velicina kljuca: ", str(keySize/8)
        print "kljuc: ", str(self.key)
        file = open(self.kljuc_path, 'w')
        file.write('---BEGIN OS2 CRYPTO DATA---\n')
        file.write('Description:\n    Secret key\n\n')
        file.write('Method:\n    AES\n\n')
        file.write('File name:\n    ')
        file.write(self.kljuc_path)
        file.write('\n\nKey length:\n    '+(str(hex(keySize/8))).replace('0x',''))
        file.write('\n\nSecret key:\n    ')        
        file.write(self.ByteToHex(self.key))
        file.write('\n\n---END OS2 CRYPTO DATA---')
        
    
    def ByteToHex(self, byteStr ):
        return ''.join( [ "%02X" % ord( x ) for x in byteStr ] ).strip()
    def HexToByte(self, hexStr ):    
        bytes = []
        hexStr = ''.join( hexStr.split(" ") )
        for i in range(0, len(hexStr), 2):
            bytes.append( chr( int (hexStr[i:i+2], 16 ) ) )
        return ''.join( bytes )
    
    def testprint(var):
        #print "var1:"+str(var)
        print "var2:"#+str(var2)
