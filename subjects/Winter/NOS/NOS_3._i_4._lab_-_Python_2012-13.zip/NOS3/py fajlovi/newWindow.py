    # display message in a child window
from Tkinter import *
import os
import subprocess as sp
import AES
import rsaController , omotnica, potpis, sha
import tkMessageBox

def aesWindow():
    win = Toplevel(height=500, width = 700)
    global aes
    # prvi red
    message = "Kljuc:"
    Label(win, text=message).grid(row=1, column = 1)
    
    kljuc_path = StringVar()
    kljuc_path.set('/aes_kljuc.txt')
    kljucEntry = Entry(win, textvariable = kljuc_path, width = 20)
    kljucEntry.grid(row=1, column = 2)

    Button(win, text='Odaberi', command=aes.odaberi_kljuc).grid(row=1, column = 3)

    Button(win, text='Pregledaj', command=aes.pregledaj_kljuc).grid(row=1, column = 4)

    Button(win, text='Generiraj', command=aesGeneriraj).grid(row=1, column = 5)

    #drugi red
    message = "Ulazna datoteka:"
    Label(win, text=message).grid(row=2, column = 1) 
    ulaz_path = StringVar()
    ulazEntry = Entry(win, textvariable = ulaz_path, width = 20)
    ulaz_path.set('/aes_ulaz.txt')
    ulazEntry.grid(row=2, column = 2)

    Button(win, text='Odaberi', command=aes.odaberi_ulaz).grid(row=2, column = 3)

    Button(win, text='Pregledaj', command=aes.pregledaj_ulaz).grid(row=2, column = 4)

    #treci red
    message = "Izlazna datoteka:"
    Label(win, text=message).grid(row=3, column = 1) 
    izlaz_path = StringVar()
    izlazEntry = Entry(win, textvariable = izlaz_path, width = 20)
    izlaz_path.set('/aes_izlaz.txt')
    izlazEntry.grid(row=3, column = 2)

    Button(win, text='Odaberi', command=aes.odaberi_izlaz).grid(row=3, column = 3)

    Button(win, text='Pregledaj', command=aes.pregledaj_izlaz).grid(row=3, column = 4)

    #cetvrti - kript=1, dekript=0 RADIOBUTTONS
    global kriptiranjeVar
    kriptiranjeVar = IntVar()
    kriptiranjeVar.set(1)
    Radiobutton(win, text = 'Kriptiranje', value = 1,
                variable = kriptiranjeVar).grid(row=4,column = 2)
    Radiobutton(win, text = 'Dekriptiranje', value = 0,
                variable = kriptiranjeVar).grid(row=4,column = 3)
    kriptiranjeVar.set(1)

    #peti - kript=1, dekript=0 RADIOBUTTONS
    global keySize
    keySize = IntVar()
    keySize.set(128)
    Radiobutton(win, text = '128', value = 128,
                variable = keySize).grid(row=5,column = 2)
    Radiobutton(win, text = '192', value = 192,
                variable = keySize).grid(row=5,column = 3)
    Radiobutton(win, text = '256', value = 256,
                variable = keySize).grid(row=5,column = 4)    
    #keySize.set(1)
    
    #sedmi - Obavi kriptiranje/dekriptiranje
    Button(win, text='Kriptiraj/Dekriptiraj', command=kriptdekript).grid(row=7, column = 3)

    #peti red - Djuro Pedala
    message = "Pedala Djuro"
    Label(win, text=message).grid(row=8, column = 5)

def kriptdekript():
    global aes
    aes.kriptdekript(kriptiranjeVar.get())
def aesGeneriraj():
    global aes
    aes.generiraj_kljuc(keySize.get())

    
## omotnica start
def omotnicaWindow():
    win = Toplevel()
    global omotnica
    # prvi red
    message = "Ulazna datoteka:"
    Label(win, text=message).grid(row=1, column = 1) 
    ulaz_path = StringVar()
    ulazEntry = Entry(win, textvariable = ulaz_path, width = 20)
    ulaz_path.set('/ulaz.txt')
    ulazEntry.grid(row=1, column = 2)

    Button(win, text='Odaberi', command=omotnica.odaberi_ulaz).grid(row=1, column = 3)

    Button(win, text='Pregledaj', command=omotnica.pregledaj_ulaz).grid(row=1, column = 4)


    #drugi red
    message = "Javni kljuc primatelja:"
    Label(win, text=message).grid(row=2, column = 1) 
    javni_path = StringVar()
    javniEntry = Entry(win, textvariable = javni_path, width = 20)
    javni_path.set('/rsa_b_javni.txt')
    javniEntry.grid(row=2, column = 2)

    Button(win, text='Odaberi', command=omotnica.odaberi_javni).grid(row=2, column = 3)

    Button(win, text='Pregledaj', command=omotnica.pregledaj_javni).grid(row=2, column = 4)

    #treci red
    message = "Digitalna omotnica:"
    Label(win, text=message).grid(row=3, column = 1) 
    omotnica_path = StringVar()
    omotnicaEntry = Entry(win, textvariable = omotnica_path, width = 20)
    omotnica_path.set('/omotnica.txt')
    omotnicaEntry.grid(row=3, column = 2)

    Button(win, text='Odaberi', command=omotnica.odaberi_omotnicu).grid(row=3, column = 3)

    Button(win, text='Pregledaj', command=omotnica.pregledaj_omotnicu).grid(row=3, column = 4)

    #Generiraj digitalnu omotnicu
    Button(win, text='Generiraj digitalnu omotnicu', command=omotnica.generiraj).grid(row=4, column = 1, columnspan = 3)

    #peti red 
    message = "Tajni kljuc primatelja:"
    Label(win, text=message).grid(row=5, column = 1) 
    tajni_path = StringVar()
    tajniEntry = Entry(win, textvariable = tajni_path, width = 20)
    tajni_path.set('/rsa_b_tajni.txt')
    tajniEntry.grid(row=5, column = 2)

    Button(win, text='Odaberi', command=omotnica.odaberi_tajni).grid(row=5, column = 3)

    Button(win, text='Pregledaj', command=omotnica.pregledaj_tajni).grid(row=5, column = 4)

    # sesti red 
    message = "Izlazna datoteka:"
    Label(win, text=message).grid(row=6, column = 1) 
    izlaz_path = StringVar()
    izlazEntry = Entry(win, textvariable = izlaz_path, width = 20)
    izlaz_path.set('/izlaz.txt')
    izlazEntry.grid(row=6, column = 2)

    Button(win, text='Odaberi', command=omotnica.odaberi_izlaz).grid(row=6, column = 3)

    Button(win, text='Pregledaj', command=omotnica.pregledaj_izlaz).grid(row=6, column = 4)

    # sedmi red
    Button(win, text='Otvori digitalnu omotnicu', command=omotnica.otvori).grid(row=7, column = 1, columnspan = 3)

    #peti red - Djuro Pedala
    message = "Pedala Djuro"
    Label(win, text=message).grid(row=8, column = 4)
    # Omotnica end!
    
    
def potpisWindow():
    win = Toplevel()
    global potpis
    # prvi red
    message = "Ulazna datoteka:"
    Label(win, text=message).grid(row=1, column = 1) 
    ulaz_path = StringVar()
    ulazEntry = Entry(win, textvariable = ulaz_path, width = 20)
    ulaz_path.set('/ulaz.txt')
    ulazEntry.grid(row=1, column = 2)

    Button(win, text='Odaberi', command=potpis.odaberi_ulaz).grid(row=1, column = 3)

    Button(win, text='Pregledaj', command=potpis.pregledaj_ulaz).grid(row=1, column = 4)


    #drugi red
    message = "Tajni kljuc posiljatelja:"
    Label(win, text=message).grid(row=2, column = 1) 
    tajni_path = StringVar()
    tajniEntry = Entry(win, textvariable = tajni_path, width = 20)
    tajni_path.set('/rsa_a_tajni.txt')
    tajniEntry.grid(row=2, column = 2)

    Button(win, text='Odaberi', command=potpis.odaberi_tajni).grid(row=2, column = 3)

    Button(win, text='Pregledaj', command=potpis.pregledaj_tajni).grid(row=2, column = 4)

    #treci red
    message = "Digitalni potpis:"
    Label(win, text=message).grid(row=3, column = 1) 
    potpis_path = StringVar()
    potpisEntry = Entry(win, textvariable = potpis_path, width = 20)
    potpis_path.set('/potpis.txt')
    potpisEntry.grid(row=3, column = 2)

    Button(win, text='Odaberi', command=potpis.odaberi_potpis).grid(row=3, column = 3)

    Button(win, text='Pregledaj', command=potpis.pregledaj_potpis).grid(row=3, column = 4)

    #Generiraj digitalni potpis
    Button(win, text='Generiraj digitalni potpis', command=potpis.generiraj).grid(row=4, column = 1, columnspan = 3)

    #peti red 
    message = "Javni kljuc posiljatelja:"
    Label(win, text=message).grid(row=5, column = 1) 
    javni_path = StringVar()
    javniEntry = Entry(win, textvariable = javni_path, width = 20)
    javni_path.set('/rsa_a_javni.txt')
    javniEntry.grid(row=5, column = 2)

    Button(win, text='Odaberi', command=potpis.odaberi_javni).grid(row=5, column = 3)

    Button(win, text='Pregledaj', command=potpis.pregledaj_javni).grid(row=5, column = 4)

    
    # sedmi red
    Button(win, text='Provjeri digitalni potpis', command=provjeriPotpis).grid(row=7, column = 1, columnspan = 3)

    #peti red - Djuro Pedala
    message = "Pedala Djuro"
    Label(win, text=message).grid(row=8, column = 4)
def provjeriPotpis():
    flag = potpis.provjeri()
    if flag:
        tkMessageBox.showinfo("Provjera potpisa", "AUTENTICNO!")
    else:
        tkMessageBox.showinfo("Provjera potpisa", "NEUSPJEH!\n Nije autenticna poruka!")
    
## pecat start
def pecatWindow():
    win = Toplevel()
    
    # prvi red
    message = "Ulazna datoteka:"
    Label(win, text=message).grid(row=1, column = 1) 
    ulaz_path = StringVar()
    ulazEntry = Entry(win, textvariable = ulaz_path, width = 20)
    ulaz_path.set('/ulaz.txt')
    ulazEntry.grid(row=1, column = 2)

    Button(win, text='Odaberi', command=win.destroy).grid(row=1, column = 3)

    Button(win, text='Pregledaj', command=win.destroy).grid(row=1, column = 4)


    #drugi red
    message = "Javni kljuc primatelja:"
    Label(win, text=message).grid(row=2, column = 1) 
    javni_b_path = StringVar()
    javniEntry = Entry(win, textvariable = javni_b_path, width = 20)
    javni_b_path.set('/rsa_b_javni.txt')
    javniEntry.grid(row=2, column = 2)

    Button(win, text='Odaberi', command=win.destroy).grid(row=2, column = 3)

    Button(win, text='Pregledaj', command=win.destroy).grid(row=2, column = 4)

    #treci red
    message = "Tajni kljuc posiljatelja:"
    Label(win, text=message).grid(row=3, column = 1) 
    tajni_a_path = StringVar()
    tajniEntry = Entry(win, textvariable = tajni_a_path, width = 20)
    tajni_a_path.set('/rsa_a_tajni.txt')
    tajniEntry.grid(row=3, column = 2)

    Button(win, text='Odaberi', command=win.destroy).grid(row=3, column = 3)

    Button(win, text='Pregledaj', command=win.destroy).grid(row=3, column = 4)

    #cetvrti red
    message = "Digitalna omotnica:"
    Label(win, text=message).grid(row=4, column = 1) 
    omotnica_path = StringVar()
    omotnicaEntry = Entry(win, textvariable = omotnica_path, width = 20)
    omotnica_path.set('/omotnica.txt')
    omotnicaEntry.grid(row=4, column = 2)

    Button(win, text='Odaberi', command=win.destroy).grid(row=4, column = 3)

    Button(win, text='Pregledaj', command=win.destroy).grid(row=4, column = 4)

    #peti red
    message = "Digitalni potpis:"
    Label(win, text=message).grid(row=5, column = 1) 
    potpis_path = StringVar()
    potpisEntry = Entry(win, textvariable = potpis_path, width = 20)
    potpis_path.set('/potpis.txt')
    potpisEntry.grid(row=5, column = 2)

    Button(win, text='Odaberi', command=win.destroy).grid(row=5, column = 3)

    Button(win, text='Pregledaj', command=win.destroy).grid(row=5, column = 4)


    #6. Generiraj digitalni pecat
    Button(win, text='Generiraj digitalni pecat', command=win.destroy).grid(row=6, column = 1, columnspan = 3)

    #7.red
    message = "Javni kljuc posiljatelja:"
    Label(win, text=message).grid(row=7, column = 1) 
    javni_a_path = StringVar()
    javniEntry = Entry(win, textvariable = javni_a_path, width = 20)
    javni_a_path.set('/rsa_a_javni.txt')
    javniEntry.grid(row=7, column = 2)

    Button(win, text='Odaberi', command=win.destroy).grid(row=7, column = 3)

    Button(win, text='Pregledaj', command=win.destroy).grid(row=7, column = 4)

    # 8. red 
    message = "Tajni kljuc primatelja:"
    Label(win, text=message).grid(row=8, column = 1) 
    tajni_b_path = StringVar()
    tajniEntry = Entry(win, textvariable = tajni_b_path, width = 20)
    tajni_b_path.set('/rsa_b_tajni.txt')
    tajniEntry.grid(row=8, column = 2)

    Button(win, text='Odaberi', command=win.destroy).grid(row=8, column = 3)

    Button(win, text='Pregledaj', command=win.destroy).grid(row=8, column = 4)

    # deveti red 
    message = "Izlazna datoteka:"
    Label(win, text=message).grid(row=9, column = 1) 
    izlaz_path = StringVar()
    izlazEntry = Entry(win, textvariable = izlaz_path, width = 20)
    izlaz_path.set('/izlaz.txt')
    izlazEntry.grid(row=9, column = 2)

    Button(win, text='Odaberi', command=win.destroy).grid(row=9, column = 3)

    Button(win, text='Pregledaj', command=win.destroy).grid(row=9, column = 4)

    # 10. red
    Button(win, text='Otvori digitalni pecat', command=win.destroy).grid(row=10, column = 1, columnspan = 3)

    #peti red - Djuro Pedala
    message = "Pedala Djuro"
    Label(win, text=message).grid(row=11, column = 4)
    # Pecat end!

def rsaWindow():
    win = Toplevel()
    global rsa
    # prvi red
    message = "Privatni kljuc:"
    Label(win, text=message).grid(row=1, column = 1)
    
    kljuc_privatni_path = StringVar()
    kljuc_privatni_path.set('/rsa_private.txt')
    kljucEntry = Entry(win, textvariable = kljuc_privatni_path, width = 20)
    kljucEntry.grid(row=1, column = 2)

    Button(win, text='Odaberi', command=rsa.odaberi_privatni_kljuc).grid(row=1, column = 3)

    Button(win, text='Pregledaj', command=rsa.pregledaj_privatni_kljuc).grid(row=1, column = 4)
    
    #drugi red
    message = "Javni kljuc:"
    Label(win, text=message).grid(row=2, column = 1) 
    kljuc_javni_path = StringVar()
    kljuc_javni_path.set('/rsa_public.txt')
    ulazEntry = Entry(win, textvariable = kljuc_javni_path, width = 20)    
    ulazEntry.grid(row=2, column = 2)

    Button(win, text='Odaberi', command=rsa.odaberi_javni_kljuc).grid(row=2, column = 3)

    Button(win, text='Pregledaj', command=rsa.pregledaj_javni_kljuc).grid(row=2, column = 4)

    
    #peti - keysize
    global keySizeRSA
    keySizeRSA = IntVar()
    keySizeRSA.set(1024)
    Radiobutton(win, text = '1024', value = 1024,
                variable = keySizeRSA).grid(row=5,column = 2)
    Radiobutton(win, text = '2048', value = 2048,
                variable = keySizeRSA).grid(row=5,column = 3)
    Radiobutton(win, text = '4096', value = 4096,
                variable = keySizeRSA).grid(row=5,column = 4)    
    #keySize.set(1)
    
    #sedmi - Obavi generiranje
    Button(win, text='Generiraj kljuceve', command=generirajRSA).grid(row=7, column = 3)

    #peti red - Djuro Pedala
    message = "Pedala Djuro"
    Label(win, text=message).grid(row=8, column = 5)

def generirajRSA():
    global rsa
    rsa.generiraj(keySizeRSA.get())
    

def pregledaj(var):
    print var.get
    #print ('gedit '+str(var) )
    #os.system('gedit '+str(var))
    #sp.Popen(["gedit",str(var)])
    return 1
def shaWindow():
    global sha
    win = Toplevel()
    message = "Izlaz:"
    Label(win, text=message).grid(row=1, column = 1)
    
    kljuc_path = StringVar()
    kljuc_path.set('/sazetak.txt')
    kljucEntry = Entry(win, textvariable = kljuc_path, width = 20)
    kljucEntry.grid(row=1, column = 2)

    Button(win, text='Odaberi', command=sha.odaberi_izlaz).grid(row=1, column = 3)
    Button(win, text='Pregledaj', command=sha.pregledaj_izlaz).grid(row=1, column = 4)


    #drugi red
    message = "Ulazna datoteka:"
    Label(win, text=message).grid(row=2, column = 1) 
    ulaz_path = StringVar()
    ulazEntry = Entry(win, textvariable = ulaz_path, width = 20)
    ulaz_path.set('/ulaz.txt')
    ulazEntry.grid(row=2, column = 2)

    Button(win, text='Odaberi', command=sha.odaberi_ulaz).grid(row=2, column = 3)
    Button(win, text='Pregledaj', command=sha.pregledaj_ulaz).grid(row=2, column = 4)

    #generiraj sazetak
    Button(win, text='Generiraj sazetak', command=prikaziSazetak).grid(row=3, column = 3)

def prikaziSazetak():
    data = sha.generiraj()
    tkMessageBox.showinfo("Sazetak:", data)

    
    
# create root window
aes = AES.AES()
sha = sha.sha()
rsa = rsaController.rsaController()
omotnica = omotnica.omotnica()
potpis = potpis.potpis()
root = Tk()
Button(root, text='AES', command=aesWindow).grid()
Button(root, text='RSA', command=rsaWindow).grid()
Button(root, text='SHA-1', command=shaWindow).grid()
Button(root, text='Omotnica', command=omotnicaWindow).grid()
Button(root, text='Potpis', command=potpisWindow).grid()
Button(root, text='Pecat', command=pecatWindow).grid()
root.mainloop()
