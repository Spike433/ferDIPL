struct msgbuf {
  long mtype;
  char mchar;
};
