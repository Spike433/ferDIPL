#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <signal.h>

#include "types.c"

#define MAX_SLEEP 3
#define DEBUG 0

int error(char* msg) {
  fprintf(stderr, "%s\n", msg);
  return EXIT_FAILURE;
}

int msgqid = 0;

void remove_queue_and_quit(int failure) {
  if (msgctl(msgqid, IPC_RMID, NULL) == -1) {
    exit(error("Couldn't remove message queue upon exit."));
  } else {
    exit(EXIT_SUCCESS);
  }
}

int main(int argc, char* argv[])
{
  struct msgbuf buf = { 1, 0 };
  key_t key = atoi(getenv("MSG_KEY"));
  int slept = 1, i = 0;
  char rcvd[200] = { 0 };

  if ((msgqid = msgget(key, 0600 | IPC_CREAT)) == -1) {
    return error("Failed to get message queue.");
  }

  sigset(SIGINT, remove_queue_and_quit);

  while (slept <= MAX_SLEEP) {
    if (msgrcv(msgqid, (struct msgbuf *)&buf, 1, 0, IPC_NOWAIT) == -1) {
      if (DEBUG) printf("Reader sleeping for %d seconds.\n", slept);
      sleep(slept++);
    } else {
      slept = 0;
      rcvd[i++] = buf.mchar;
      if (buf.mchar == '\0') {
        printf("Got message: %s.\n", rcvd);
        i = 0;
      }
    }
  }

  if (DEBUG) printf("Message queue empty; reader done; quitting.\n");
  remove_queue_and_quit(0);
}
