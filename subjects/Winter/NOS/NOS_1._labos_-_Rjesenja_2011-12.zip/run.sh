#!/usr/bin/env sh

export MSG_KEY=`grep $USER /etc/passwd | cut -d: -f3`

for a in $@
do
    ./writer $a &
done

./reader
