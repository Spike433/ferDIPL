#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#include "types.c"

#define DEBUG 0

int error(char* msg) {
  fprintf(stderr, "%s\n", msg);
  return EXIT_FAILURE;
}

int main(int argc, char* argv[])
{
  struct msgbuf buf = { 1, 0 };
  struct msqid_ds queue_status;
  key_t key = atoi(getenv("MSG_KEY"));
  int msgqid = -1, c = 0, i = 0, l = 0;

  if (argc < 2) {
    return error("Insufficient arguments. Need at least one char to send.");
  }

  if ((msgqid = msgget(key, 0600 | IPC_CREAT)) == -1) {
    return error("Failed to get message queue.");
  }

  if (msgctl(msgqid, IPC_STAT, &queue_status) == -1) {
    return error("Failed to get message queue status.");
  } else {
    queue_status.msg_qbytes = 5;
    if (msgctl(msgqid, IPC_SET, &queue_status) == -1) {
      return error("Failed to set message queue maximum byte number.");
    }
  }

  for (i = 1; i < argc; i++) {
    l = strlen(argv[i]);
    for (c = 0; c <= l; c++) {
      buf.mchar = c != l ? argv[i][c] : '\0';
      if (msgsnd(msgqid, (struct msgbuf*)&buf, 1, 0) == -1) {
        return error("Unable to send message.");
      } else if (DEBUG) {
        printf("Sent message '%c'.\n", buf.mchar);
      }
    }
  }

  if (DEBUG) printf("Writer done; quitting.\n");
  return EXIT_SUCCESS;
}
