(defproject aes-nos "0.1.0-SNAPSHOT"
  :description "AES via ECB and OFB"
  :url "http://example.com/FIXME"
;  :warn-on-reflection true
  :dependencies [[org.clojure/clojure "1.3.0"]
                 [criterium "0.2.1"]])