(ns aes-nos.const)

;; The number of rounds performed depends on the key length.
(def ^:const aes-rounds {16 10, 24 12, 32 14})

;; The used block size in bytes.
(def ^:const block-size 16)

;; If no key-len is specified, this one is used.
(def ^:const default-key-len 16)

; Only keys of certain lengths in bytes are supported by this implementation.
(def ^:const valid-key-length #{16 24 32})