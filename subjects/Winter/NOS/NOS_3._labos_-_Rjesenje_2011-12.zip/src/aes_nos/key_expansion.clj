(ns aes-nos.key-expansion
  (:require [aes-nos.bytes  :as b]
            [aes-nos.tables :as table])
  (:use aes-nos.const))

; During key expansion, we perform extra steps depending on the key length.
(def ^:const key-expansion-extra-steps {16 0, 24 2, 32 3})

(defn key-schedule-core
  "Performs the following operations on the input word: left-rotates by one
   byte, then applies the S-Box to all bytes, then applies the Rcon table to
   a single left-most byte. Returns the resulting word."
  [^bytes word i]
  (let [rotd (b/rotl word) ; TODO SIMPLIFY THIS
        boxd (b/map-expr! rotd i ret (b/get-wrap table/sbox (b/get ret i)))]
    (b/put-with! #(bit-xor (b/get-wrap table/rcon i) %) boxd 0)
    boxd))

(defn extend-key-with-word
  [xkey word]
  (swap! xkey #(b/concat % @word)))

(defn special-subst
  "Special substitution step for the 256-bit key, during key extension."
  [word xkey key-size]
  (let [fun #(bit-xor (b/get-wrap table/sbox %1)
                      (b/get-wrap @xkey (- %2 key-size)))]
    (swap! word #(b/map-with-i fun %))
    (extend-key-with-word xkey word)))

(defn mix-in-last-subkey
  [word xkey i key-size]
  (let [fun #(bit-xor % (b/get-wrap @xkey (- i key-size)))]
    (swap! word #(b/put-with fun % i))))

(defn expand-key ; TODO pretty this up, it's horrible
  "Performs expansion of the input key. Returns an expanded key."
  [^bytes key]
  (let [xkey (atom (b/copy key))
        word (atom (byte-array 4 (take-last 4 key)))
        done (atom false)
        key-size (b/len key)
        rounds (aes-rounds key-size)]

    (doseq [i (range 1 11) :while (not @done)]
      (swap! word key-schedule-core i)

      (dotimes [_ 4]
        (dotimes [j 4]
          (mix-in-last-subkey word xkey j key-size))
        (extend-key-with-word xkey word))

      (if (>= (b/len ^bytes @xkey) (* block-size (inc rounds)))
        (reset! done true)
        (do
          (when (== key-size 32)
            (special-subst word xkey key-size))
          (dotimes [_ (key-expansion-extra-steps key-size)]
            (dotimes [j 4]
              (mix-in-last-subkey word xkey j key-size))
            (extend-key-with-word xkey word)))))

    @xkey))