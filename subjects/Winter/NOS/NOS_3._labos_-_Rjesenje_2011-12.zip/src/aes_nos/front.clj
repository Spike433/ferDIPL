(ns aes-nos.front
  "The front-facing interface for blafsdflf."
  (:require [aes-nos.modes :as modes]
            [aes-nos.bytes :as b])
  (:use aes-nos.const))

;; We can encrypt or decrypt by ecb or ofb.
(def ^:private available-methods
  {:encrypt {:ecb modes/encrypt-ecb :ofb modes/encrypt-ofb}
   :decrypt {:ecb modes/decrypt-ecb :ofb modes/decrypt-ofb}})

(defn- convert-in
  "Used to convert incoming data to a format the crypto functions expect."
  [data]
  (cond
    (string? data) (b/from-utf-8 data)
    :all-others data))

(defn aes
  "Interface to all the encrypt/decrypt ecb/ofb methods."
  [text-or-bytes ^String password & [op mode key-len]]

  (let [len  (valid-key-length (or key-len default-key-len))
        func (mode (op available-methods))
        in   (convert-in text-or-bytes)
        pass (b/from-utf-8 password)]

    (if (and func len)
      (func in pass len)
      :invalid-aes-args)))

(defn- test-ecb
  [^String text ^String pass]
  (let [encd (aes text pass :encrypt :ecb 24)
        decd (aes encd pass :decrypt :ecb 24)]
    (println "Input was:" text)
    (println "Encrypted:" (seq encd))
    (if (nil? decd)
      (println "Couldn't decrypt.")
      (println "Decrypted:" (b/to-utf-8 decd)))))

(defn- test-ofb
  [^String text ^String pass]
  (let [encd (aes text pass :encrypt :ofb 24)
        decd (aes encd pass :decrypt :ofb 24)]
    (println "Input was:" text)
    (println "Encrypted:" (b/to-utf-8 encd))
    (if (nil? decd)
      (println "Couldn't decrypt.")
      (println "Decrypted:" (b/to-utf-8 decd)))))

(def ^:private ^:const sample-text
  "This method converts a block cipher into a stream cipher. The initialization
   vector is enciphered using the specified block algorithm. This is then
   exclusive-or'd with the message, and also saved to encipher the next
   block. One advantage of this mode is that the message unit sizes don't have
   to match the encryption algorihtm, and can even vary in size. For example, a
   128-bit AES algorithm can be used to encrypt a series of 16-bit
   messages. Futhermore, encryption and decryption become identical (only the
   encipher function of the underlying block cipher is used), simplifying the
   implementation.")