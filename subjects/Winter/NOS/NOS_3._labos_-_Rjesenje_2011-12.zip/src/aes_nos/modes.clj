(ns aes-nos.modes
  "Defines the ECB and OFB block cipher modes of operation."
  (:require [aes-nos.core :as core]
            [aes-nos.bytes :as b])
  (:use aes-nos.const))

(defn- sha256
  "Calculates and returns the SHA-256 hash of the given input byte array."
  [^bytes bs]
  (let [hash (java.security.MessageDigest/getInstance "SHA-256")]
    (.digest hash bs)))

(defn create-key
  "Creates a key according to the given password and wanted key length."
  [^bytes password key-len]
  (b/take key-len (sha256 password)))

(defn- add-padding
  "Adds padding to the end of the byte array, to make its length in bytes a
   multiple of the block-size. At least one extra byte is mandatory."
  [^bytes bs]
  (let [pad (- block-size (rem (b/len bs) block-size))]
    (b/concat bs (byte-array (map unchecked-byte (repeat pad pad))))))

(defn- remove-padding
  "Removes the previously-added padding. If the last block byte is not
   suitable as padding, returns nil. This means the array was either
   not padded, or has been incorrectly decrypted."
  [^bytes bs]
  (let [l (b/len bs) last-byte (b/get bs (unchecked-dec l))]
    (cond
      (> last-byte l) nil ; Probably decryption failed; return nil.
      :else-all-is-ok (b/take (- l last-byte) bs))))

(defn encrypt-ecb-raw
  "Encrypts a byte array using the ECB mode."
  [^bytes bs ^bytes key]
  (let [enc (core/get-encrypt-func key)]
    (apply b/concat (pmap enc (b/split (add-padding bs) block-size)))))

(defn encrypt-ecb
  "Encrypts a byte array using the ECB mode."
  [^bytes bs password key-len]
  (encrypt-ecb-raw bs (create-key password key-len)))

(defn decrypt-ecb-raw
  "Decrypts a byte array using the ECB mode."
  [^bytes bs ^bytes key]
  (let [dcr (core/get-decrypt-func key)]
    (remove-padding (apply b/concat (pmap dcr (b/split bs block-size))))))

(defn decrypt-ecb
  "Decrypts a byte array using the ECB mode."
  [^bytes bs password key-len]
  (decrypt-ecb bs (create-key password key-len)))

(defn- zip-with
  "Applies a function to pairs of elements of the two lists, returning the
   results in a new list."
  [f xs ys]
  (when (and (seq xs) (seq ys))
    (cons (f (first xs) (first ys))
          (zip-with f (next xs) (next ys)))))

(defn crypt-ofb-raw
  "Encrypts or decrypts a byte array using the OFB mode.
   Does not perform any padding operations."
  [^bytes bs key]
  (let [enc  (core/get-encrypt-func key)
        iv   (create-key key block-size) ; SHA-256 the key to get init vector.
        bnum (/ (b/len bs) block-size)]  ; How many blocks are we dealing with?
    (apply b/concat
       (zip-with #(b/zip-with bit-xor %1 %2) ; XOR each of the blocks.
                  (b/split bs block-size)
                  (take bnum (iterate enc iv))))))

(defn encrypt-ofb
  "Adds padding and crypts via crypt-ofb."
  [^bytes bs password key-len]
  (crypt-ofb-raw (add-padding bs) (create-key password key-len)))

(defn decrypt-ofb
  "Crypts via crypt-ofb and removes padding."
  [^bytes bs password key-len]
  (remove-padding (crypt-ofb-raw bs (create-key password key-len))))
