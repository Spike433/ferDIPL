(ns aes-nos.bytes
  "Operations on bytes arrays.")

(defmacro new
  [xs]
  `(byte-array (map unchecked-byte ~xs)))

(defn get
  [^bytes bs i]
  (aget bs i))

(defn copy
  "Copy a byte array. Return the copy."
  [^bytes bs]
  (aclone bs))

(defn put!
  "Set a byte in a position in a byte array, destructively."
  [^bytes bs i val]
  (aset-byte bs i val))

(defn swap!
  [^bytes bs x y]
  (let [temp (get bs x)]
    (put! bs x (get bs y))
    (put! bs y temp)
    bs))

(defn put-with
  "Applies a function to a specific position (byte) in a byte array.
   Returns a new byte array with the chosen byte modified."
  [f ^bytes in-bs i]
  (let [^bytes bs (copy in-bs)]
    (put! bs i (unchecked-byte (f (get bs i))))
    bs))

(defn put-with!
  "Applies a function to a specific byte in an array, destructively.
   Returns the input byte array, only modified in-place."
  [f ^bytes bs i]
  (put! bs i (unchecked-byte (f (get bs i)))))

(defn len
  "Gets the length of the input byte array."
  [^bytes bs]
  (alength bs))

(defn get-wrap
  "Like get, but tolerates out-of-bounds arguments. Wraps around."
  [^bytes bs i]
  (get bs (mod i (len bs))))

(defn from-utf-8
  "Convert an UTF-8-encoded string to a byte array."
  [^String s]
  (.getBytes s "UTF-8"))

(defn to-utf-8
  "Convert a byte array to an UTF-8-encoded string."
  [^bytes bs]
  (String. bs "UTF-8"))

(defn to-ascii
  "Convert a byte array to an ASCII-encoded string."
  [^bytes bs]
  (String. bs "ascii"))

(defn from-ascii
  "Convert an ASCII-encoded string to a byte array."
  [^String s]
  (.getBytes s "ascii"))

(defn append
  "Append the second byte array to the first. Returns a new byte array."
  [^bytes x ^bytes y]
  (let [lx (len x), ly (len y),
        ^bytes new (byte-array (+ lx ly))]
    (System/arraycopy x 0 new 0 lx)
    (System/arraycopy y 0 new lx ly)
    new))

(defn concat
  "Concatenates any number of byte arrays.
   Returns a new byte array with the concatenated arguments."
  [^bytes x & ys]
  (if (empty? ys)
    x ; No other arrays to append.
    (let [new (append x (first ys))]
      (apply concat (cons new (next ys))))))

(defmacro map-expr!
  "Maps an expression to each byte of the array, destructively."
  [a idx ret expr]
  `(let [~ret ~a l# (len ~ret)]
     (loop  [~idx (int 0)]
       (if (< ~idx l#)
         (do
           (put! ~ret ~idx ~expr)
           (recur (unchecked-inc ~idx)))
         ~ret))))

(defmacro map-expr
  "Maps an expression to each byte of the array.
   Returns a new byte array with the results."
  [a idx ret expr]
  `(let [a# ~a
         ~ret (copy a#)]
     (loop  [~idx (int 0)]
       (if (< ~idx  (len a#))
         (do
           (put! ~ret ~idx ~expr)
           (recur (unchecked-inc ~idx)))
         ~ret))))

(defmacro map
  "Map a function to each byte of an array."
  [f a]
  `(map-expr ~a ~'i ~'ret (~f (get ~'ret ~'i))))

(defmacro map!
  "Map a function to each byte of an array, destructively."
  [f a]
  `(map-expr! ~a ~'i ~'ret (~f (get ~'ret ~'i))))

(defmacro map-with-i
  "Map a function to each byte and its index."
  [f a]
  `(map-expr ~a ~'i ~'ret (~f (get ~'ret ~'i) ~'i)))

(defmacro map-with-i!
  "Map a function to each byte and its index, destructively."
  [f a]
  `(map-expr! ~a ~'i ~'ret (~f (get ~'ret ~'i) ~'i)))

(defn zip-with
  "Map a function over the pairs of elements of two lists."
  [f ^bytes xs ys]
  (map-expr xs i ret (f (get ret i) (get ys i))))

(defn span
  "Returns a copy of a span of bytes in a byte array."
  [^long from ^long to ^bytes bs]
  (java.util.Arrays/copyOfRange bs from to))

(defmacro take
  "Returns a copy of the first n bytes in a byte array."
  [n bs]
  `(span 0 ~n ~bs))

(defmacro drop
  "Returns a copy of the byte array lacking the first n bytes."
  [n bs]
  `(span ~n (len ~bs) ~bs))

(defn split
  "Splits the input array into a list of size'd chunks."
  [^bytes bs size]
  (for [i (range 0 (len bs) size)]
    (span i (+ i size) bs)))

(defn rotl
  "Rotates a byte array a number of byte-sized times into the left.
   Returns a new rotated byte array. Rotates by one by default."
  [^bytes bs & [times]]
  (let [rot (or times 1)]
    (concat (drop rot bs) (take rot bs))))

(defn rotr
  "Rotates a byte array a number of byte-sized times into the right.
   Returns a new rotated byte array. Rotates by one by default."
  [^bytes bs & [times]]
  (let [rot (or times 1)]
    (rotl bs (- (len bs) rot))))