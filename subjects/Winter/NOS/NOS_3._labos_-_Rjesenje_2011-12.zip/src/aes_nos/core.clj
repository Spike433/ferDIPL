(ns aes-nos.core
  "Defines the core AES algorithm."
  (:require [aes-nos.bytes  :as b]      ; Byte-array operations.
            [aes-nos.tables :as table]) ; Cached tables, sbox, galois...
  (:use [aes-nos.key-expansion :only (expand-key)])
  (:use  aes-nos.const))

(defmacro mult
  "Multiply two bytes according to finite field arithmetic."
  [x y]
  `(b/get-wrap (table/mult (unchecked-byte ~x)) (unchecked-byte ~y)))

(defn- add-round-key!
  "XOR each block byte with a corresponding one in the key."
  [^bytes block ^bytes key ^long round]
  (let [offset (* round block-size)]
    (b/map-with-i! #(bit-xor %1 (b/get key (+ offset %2))) block)))

(defn- sub-bytes!
  "Substitute each byte of the block using an sbox."
  [^bytes block mode]
  (let [sbox (if (= mode :inverse) table/inv-sbox table/sbox)]
    (b/map! #(b/get-wrap sbox %1) block)))

;; Which bytes do we swap when shifting the rows?
(def ^:private ^:const shift-rows-steps
  {:regular [[1  5] [5 9] [9 13] [2 10] [6 14] [3 11] [7 11] [3 15]]
   :inverse [[9 13] [5 9] [1  5] [2 10] [6 14] [3 15] [7 11] [3 11]]})

(defn- shift-rows!
  "Performs the shift rows step in-place."
  [^bytes block mode]
  (doseq [[i j] (shift-rows-steps mode)]
    (b/swap! block i j)))

(defn- mix-columns!
  "Performs the mix columns step, in-place."
  [^bytes block mode]

  (let [mix (if (= mode :inverse) ; Mix func depends on whether inverse or not.
              #(bit-xor (mult 2  %1)          %2           %3  (mult 3  %4))
              #(bit-xor (mult 14 %1) (mult 9  %2) (mult 13 %3) (mult 11 %4)))]

    (doseq [col (range 0 block-size 4)]
      (let [[v0 v1 v2 v3] (map #(b/get block %) (take 4 (iterate inc col)))]
        (b/put! block    col    (mix v0 v3 v2 v1))
        (b/put! block (+ col 1) (mix v1 v0 v3 v2))
        (b/put! block (+ col 2) (mix v2 v1 v0 v3))
        (b/put! block (+ col 3) (mix v3 v2 v1 v0))))))

(defn- encrypt!
  "Encrypt a block-sized byte array according to a key and number of rounds.
   Updates the byte array in-place."
  [^bytes key ^long rs ^bytes bs]

  (add-round-key! bs key 0)
  (doseq [r (range 1 rs)]
    (sub-bytes!     bs :regular)
    (shift-rows!    bs :regular)
    (mix-columns!   bs :regular)
    (add-round-key! bs key r))
  (sub-bytes!     bs :regular)
  (shift-rows!    bs :regular)
  (add-round-key! bs key rs)
  bs)

(defn- decrypt!
  "Decrypt a block-sized byte array according to a key and number of rounds.
   Updates the byte array in-place."
  [^bytes key ^long rs ^bytes bs]

  (add-round-key! bs key rs)
  (doseq [r (range (unchecked-dec rs) 0 -1)]
    (shift-rows!    bs :inverse)
    (sub-bytes!     bs :inverse)
    (add-round-key! bs key r)
    (mix-columns!   bs :inverse))
  (shift-rows!    bs :inverse)
  (sub-bytes!     bs :inverse)
  (add-round-key! bs key 0)
  bs)

(defn get-encrypt-func
  "Returns a function that will encrypt a block according to the given key."
  [^bytes key]
  (partial encrypt! (expand-key key) (aes-rounds (b/len key))))

(defn get-decrypt-func
  "Returns a function that will decrypt a block according to the given key."
  [^bytes key]
  (partial decrypt! (expand-key key) (aes-rounds (b/len key))))
