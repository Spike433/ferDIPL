#!/usr/bin/env python

from sys import argv
from random import randint
from multiprocessing import Process, Pipe

NUM_CHILDREN = int(argv[1])

# Stvorimo NUM_CHILDREN one-directional cjevovoda.
pipes = [Pipe(False) for i in range(NUM_CHILDREN)]

# Proces-dijete prima i ispisuje poruke sve dok ne primi None.
def run_child(pipe, my_num):
    out = open('%d.txt' % my_num, 'w')

    while True:
        val = pipe.recv()
        if val is None: break
        out.write('%s\n' % val)

    out.close()

# Započnemo NUM_CHILDREN procesa.
for n, (pipe, _) in zip(range(NUM_CHILDREN), pipes):
    Process(target=run_child, args=(pipe, n)).start()

# Svaku liniju datoteke šaljemo nasumičnom procesu.
for line in open('messages', 'r'):
    val = line.strip()
    child = randint(0, NUM_CHILDREN-1)
    pipes[child][1].send(val)
    print("Poslao poruku \"%s\" procesu %d." % (val, child))

# Poručujemo procesima da mogu prestati slušati.
for _, pipe in pipes:
    pipe.send(None)
