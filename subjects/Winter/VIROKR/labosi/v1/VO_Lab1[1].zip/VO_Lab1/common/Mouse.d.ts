export declare class Mouse {
    lastX: any;
    lastY: any;
    mouseDown: boolean;
    downCallback: any;
    moveCallback: any;
    scrollCallback: any;
    firstMouse: boolean;
    constructor();
}
