export const fs_normal_mapping =
    `#version 300 es
precision mediump float;

out vec4 FragColor;

in  vec3 FragPos;
in  vec3 Normal;
in  vec2 TexCoords;
in  vec3 TangentLightPos;
in  vec3 TangentViewPos;
in  vec3 TangentFragPos;

uniform sampler2D diffuseMap;
uniform sampler2D normalMap;

uniform vec3 lightPos;
uniform vec3 viewPos;

void main()
{   
    //---------------------------------------------------------------
    // 1.) Izračunatu normalu (dobivenu interpolacijom između
	// vrijednosti normala s obližnjih vrhova) zamijenite s
	// vrijednosti iz teksture normalMap dobivene korištenjem funkcije
    //   texture(texture_sampler, coordinate).rgb
	// Dobivena vrijednost je u intervalu vrijednosti [0,1] pa ju treba
	// transformirati u interval [-1,1] te normalizirati funkcijom
	//   normalize()
    //---------------------------------------------------------------

    vec3 n = normalize(Normal);
    
    //---------------------------------------------------------------
	// 2.) Poluvektor h izračunajte pomoću normaliziranih vektora 
	// smjera izvora svjetlosti (l) i vektora smjera gledanja (v).
	// Dobiveni vektor također normalizirajte.
	//---------------------------------------------------------------

    vec3 l = normalize(TangentLightPos - TangentFragPos);
    vec3 v = normalize(TangentViewPos - TangentFragPos);
    vec3 h = vec3(0.0);
   
    //----------------------------------------------------------------
	// Izračun veličine difuzne komponente
	//	(vidi izraz u uputama, poglavlje (2.1))
	//----------------------------------------------------------------

    //float nDotL = dot(n, l);
    float nDotL = max(dot(n, l), 0.0);

    //----------------------------------------------------------------
	// 3.) Izračunajte veličinu reflektirajuće komponente tako da 
	// potencirate (funkcijom pow(x,y)) skalarni umnožak normale i
	// izračunati poluvektor h.
	//----------------------------------------------------------------

    float nSpecL = 0.0;

    // get diffuse color
    vec3 color = texture(diffuseMap, TexCoords).rgb;
    // ambient
    vec3 ambient = 0.1 * color;
    // diffuse
    vec3 diffuse = nDotL * color;
    // specular
    vec3 specular = nSpecL * vec3(0.75);

    //-----------------------------------------------------------
    // 4.) UKUPNI EFEKT OSVJETLJENJA čine ambijentalna, difuzna i 
	// reflektirajuća komponenta (koju još treba dodati).
    //-----------------------------------------------------------

    FragColor = vec4(ambient + diffuse, 1.0);
}`