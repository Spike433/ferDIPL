export const fs_shadow_mapping =
    `#version 300 es
precision mediump float;

out vec4 FragColor;

in vec3 FragPos;
in vec3 Normal;
in vec2 TexCoords;
in vec4 FragPosLightSpace;

uniform sampler2D diffuseTexture;
uniform sampler2D shadowMap;

uniform vec3 lightPos;
uniform vec3 viewPos;

float ShadowCalculation(vec4 fragPosLightSpace)
{
    //-----------------------------------------------------------
    // 1.) Da bi se učitala dubina, prvo je potrebno x, y i z komponente
	// fragPosLightSpace vektora svesti na normaliziranu vrijednost
	// dijeljenjem sa .w komponentom te translacijom tako dobivenih
    // vrijednosti sa intervala [-1,1] na [0,1].
    //-----------------------------------------------------------




    //-----------------------------------------------------------
    // 2.) Da bi se ostvario efekt ShadowMappinga, potrebno je 
    // učitati spremljenu dubinu iz shadowMap teksture (x i y komponenta).
    // Koristite funkciju: texture(texture_sampler, coordinate).r
    //-----------------------------------------------------------




    //-----------------------------------------------------------
    // 3.) Dobivenu vrijednost dubine usporedite sa udaljenosti
    // trenutne točke (z komponenta dubine). Ako su vrijednosti 
    // približno iste (bias = 0.01), točka se nalazi na svjetlu 
    // te ju je potrebno u potpunosti osvijetliti (shadow = 0.0). 
    // U suprotnom slučaju, potrebno ju je osvijetliti samo
    // ambijentalnim svjetlom (shadow = 1.0).
    //-----------------------------------------------------------




    //-----------------------------------------------------------
    // 4.) Zadržite sjenu na 0,0 kada je izvan područja daleke ravnine,
    // odnosno kada je z koordinata projiciranog vektora veća od 1,0.
    //-----------------------------------------------------------


    
    float shadow = 0.0;
    return shadow;
}

void main()
{           
    vec3 color = texture(diffuseTexture, TexCoords).rgb;
    vec3 normal = normalize(Normal);
    vec3 lightColor = vec3(0.3);
    // ambient
    vec3 ambient = 0.3 * lightColor;
    // diffuse
    vec3 lightDir = normalize(lightPos - FragPos);
    float diff = max(dot(lightDir, normal), 0.0);
    vec3 diffuse = diff * lightColor;
    // specular
    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 reflectDir = reflect(-lightDir, normal);
    float spec = 0.0;
    vec3 halfwayDir = normalize(lightDir + viewDir);  
    spec = pow(max(dot(normal, halfwayDir), 0.0), 64.0);
    vec3 specular = spec * lightColor;    
    // calculate shadow
    float shadow = ShadowCalculation(FragPosLightSpace);                      
    vec3 lighting = (ambient + (1.0 - shadow) * (diffuse + specular)) * color;    
    
    FragColor = vec4(lighting, 1.0);
}`