export const fs_shadow_mapping_depth =
    `#version 300 es
precision mediump float;

void main()
{
    // gl_FragDepth = gl_FragCoord.z;
}`