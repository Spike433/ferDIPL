// This code is a javascript translation of code originally written by Joey de Vries under the CC BY-NC 4.0 licence. 
// For more information please visit https://learnopengl.com/About


import { vec2, vec3, mat4 } from '../../math/glmatrix/index.js';
import { fs_debug_quad_depth } from './shaders/fs_debug_quad_depth.js';
import { fs_shadow_mapping_depth } from './shaders/fs_shadow_mapping_depth.js';
import { fs_shadow_mapping } from './shaders/fs_shadow_mapping.js';
import { vs_debug_quad } from './shaders/vs_debug_quad.js';
import { vs_shadow_mapping_depth } from './shaders/vs_shadow_mapping_depth.js';
import { vs_shadow_mapping } from './shaders/vs_shadow_mapping.js';
import { Shader } from '../../common/Shader.js';
import { Mouse } from '../../common/Mouse.js';
import { KeyInput } from '../../common/KeyInput.js';
import { Camera, CameraMovement } from '../../common/Camera.js';

const sizeFloat = 4;
const picture = "wood.png"
const logo = "Logo.png"
const SCREEN_WIDTH = screen.width, SCREEN_HEIGHT = screen.height;
const SHADOW_WIDTH = 1024, SHADOW_HEIGHT = 1024;

// canvas
let canvas = document.createElement('canvas');
canvas.width = window.innerWidth - 16;
canvas.height = window.innerHeight - 16;
document.body.appendChild(canvas);

// initialization
var gl = canvas.getContext('webgl2', { antialias: true });
let shader, simpleDepthShader, debugDepthQuad = null;
let projection = mat4.create(), view = mat4.create();
let woodTexture;
let logoTexture;
let lightPos;

// meshes
let planeVAO, planeVBO = null;
let quadVAO, quadVBO = null;
let cubeVAO, cubeVBO = null;
let depthMapFBO = null, depthMap = null;

// input
const GLFW_KEY_W = 'w', GLFW_KEY_S = 's', GLFW_KEY_A = 'a', GLFW_KEY_D = 'd', GLFW_KEY_SPACE = ' ';
let keyInput = new KeyInput({ GLFW_KEY_W, GLFW_KEY_S, GLFW_KEY_A, GLFW_KEY_D, GLFW_KEY_SPACE });

// camera
let camera = new Camera(vec3.fromValues(0.0, 0.0, 4.0), vec3.fromValues(0.0, 1.0, 0.0));

// mouse
let mouse = new Mouse();
mouse.moveCallback = mouse_move_callback;
mouse.scrollCallback = mouse_scroll_callback;

// timing
let deltaTime = 0.0;
let lastFrame = 0.0;

let main = function () {
    // configure global opengl state
    // -----------------------------
    gl.enable(gl.DEPTH_TEST);

    // build and compile shaders
    // -------------------------
    shader = new Shader(gl, vs_shadow_mapping, fs_shadow_mapping);
    simpleDepthShader = new Shader(gl, vs_shadow_mapping_depth, fs_shadow_mapping_depth);
    debugDepthQuad = new Shader(gl, vs_debug_quad, fs_debug_quad_depth);

    // set up vertex data (and buffer(s)) and configure vertex attributes
    // ------------------------------------------------------------------
    let planeVertices = new Float32Array([
        // positions      // normal      // texcoords    
        25.0, -0.5, 25.0, 0.0, 1.0, 0.0, 25.0, 0.0,
        -25.0, -0.5, 25.0, 0.0, 1.0, 0.0, 0.0, 0.0,
        -25.0, -0.5, -25.0, 0.0, 1.0, 0.0, 0.0, 25.0,

        25.0, -0.5, 25.0, 0.0, 1.0, 0.0, 25.0, 0.0,
        -25.0, -0.5, -25.0, 0.0, 1.0, 0.0, 0.0, 25.0,
        25.0, -0.5, -25.0, 0.0, 1.0, 0.0, 25.0, 10.0
    ]);
    // plane VAO
    planeVAO = gl.createVertexArray();
    planeVBO = gl.createBuffer();
    gl.bindVertexArray(planeVAO);
    gl.bindBuffer(gl.ARRAY_BUFFER, planeVBO);
    gl.bufferData(gl.ARRAY_BUFFER, planeVertices, gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 8 * sizeFloat, 0);
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 8 * sizeFloat, 3 * sizeFloat);
    gl.enableVertexAttribArray(2);
    gl.vertexAttribPointer(2, 2, gl.FLOAT, false, 8 * sizeFloat, 6 * sizeFloat);
    gl.bindVertexArray(null);

    // load textures
    // -------------
    woodTexture = loadTexture("../../textures/" + picture, 4, false);
    logoTexture = loadTexture("../../textures/" + logo, 4, false);

    // configure depth map FBO
    // -----------------------
    depthMapFBO = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, depthMapFBO)

    // create depth texture
    depthMap = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, depthMap)
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.DEPTH_COMPONENT32F, SHADOW_WIDTH, SHADOW_HEIGHT, 0, gl.DEPTH_COMPONENT, gl.FLOAT, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    // attach depth texture as FBO's depth buffer
    gl.bindFramebuffer(gl.FRAMEBUFFER, depthMapFBO);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, depthMap, 0);
    gl.drawBuffers([gl.NONE]);
    gl.readBuffer(gl.NONE);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);

    // shader configuration
    // --------------------
    shader.use(gl);
    shader.setInt(gl, "diffuseTexture", 0);
    shader.setInt(gl, "shadowMap", 1);
    debugDepthQuad.use(gl);
    debugDepthQuad.setInt(gl, "depthMap", 0);

    // lighting info
    // -------------
    lightPos = vec3.fromValues(-2.0, 4.0, -1.0);

    animate();
}();

function animate() {
    render();
    requestAnimationFrame(animate);
}

function render() {
    // per-frame time logic
    // --------------------
    let currentFrame = performance.now();
    deltaTime = currentFrame - lastFrame;
    lastFrame = currentFrame;

    // input
    // -----
    processInput();

    // render
    // ------
    gl.clearColor(0.1, 0.1, 0.1, 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // 1. render depth of scene to texture (from light's perspective)
    // --------------------------------------------------------------
    let lightProjection = mat4.create();
    let lightView = mat4.create();
    let lightSpaceMatrix = mat4.create();
    var near_plane = 1.0;
    var far_plane = 7.5;
    mat4.ortho(lightProjection, -10.0, 10.0, -10.0, 10.0, near_plane, far_plane);
    mat4.lookAt(lightView, lightPos, vec3.fromValues(0.0, 0.0, 0.0), vec3.fromValues(0.0, 1.0, 0.0));
    mat4.multiply(lightSpaceMatrix, lightProjection, lightView);
    // render scene from light's point of view
    simpleDepthShader.use(gl);
    gl.uniformMatrix4fv(gl.getUniformLocation(simpleDepthShader.programId, "lightSpaceMatrix"), false, lightSpaceMatrix);

    gl.viewport(0, 0, SHADOW_WIDTH, SHADOW_HEIGHT);
    gl.bindFramebuffer(gl.FRAMEBUFFER, depthMapFBO);
    gl.clear(gl.DEPTH_BUFFER_BIT);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, woodTexture);
    renderScene(simpleDepthShader);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);

    // reset viewport
    gl.viewport(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // 2. render scene as normal using the generated depth/shadow map
    // --------------------------------------------------------------
    gl.viewport(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    mat4.perspective(projection, (camera.Zoom) * Math.PI / 180, canvas.width / canvas.height, 0.1, 100.0);
    view = camera.GetViewMatrix();
    shader.use(gl);
    gl.uniformMatrix4fv(gl.getUniformLocation(shader.programId, "projection"), false, projection);
    gl.uniformMatrix4fv(gl.getUniformLocation(shader.programId, "view"), false, view);
    // set light uniforms
    gl.uniform3fv(gl.getUniformLocation(shader.programId, "viewPos"), camera.Position);
    gl.uniform3fv(gl.getUniformLocation(shader.programId, "lightPos"), lightPos);
    gl.uniformMatrix4fv(gl.getUniformLocation(shader.programId, "lightSpaceMatrix"), false, lightSpaceMatrix);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, woodTexture);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, depthMap);
    renderScene(shader);

    // render Depth map to quad for visual debugging
    // ---------------------------------------------
    debugDepthQuad.use(gl);
    debugDepthQuad.setFloat(gl, "near_plane", near_plane);
    debugDepthQuad.setFloat(gl, "far_plane", far_plane);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, depthMap);
    // renderQuad();
}

// renders the 3D scene
// --------------------
function renderScene(shader) {
    // per-frame time logic
    // --------------------
    let currentFrame = performance.now();
    deltaTime = currentFrame - lastFrame;
    lastFrame = currentFrame;
    // floor
    let model = mat4.create();
    let axis = vec3.create();
    vec3.normalize(axis, vec3.fromValues(1.0, 0.0, 1.0));
    gl.uniformMatrix4fv(gl.getUniformLocation(shader.programId, "model"), false, model);
    gl.bindVertexArray(planeVAO);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    // cubes
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, logoTexture);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, depthMap);
    model = mat4.create();
    mat4.translate(model, model, vec3.fromValues(0.0, 1.5, 0.0));
    mat4.scale(model, model, vec3.fromValues(0.5, 0.5, 0.5));
    mat4.rotate(model, model, (currentFrame / 50.0) * Math.PI / 180, axis);
    gl.uniformMatrix4fv(gl.getUniformLocation(shader.programId, "model"), false, model);
    renderCube();
    model = mat4.create();
    mat4.translate(model, model, vec3.fromValues(2.0, 0.0, 1.0));
    mat4.scale(model, model, vec3.fromValues(0.5, 0.5, 0.5));
    gl.uniformMatrix4fv(gl.getUniformLocation(shader.programId, "model"), false, model);
    renderCube();
    model = mat4.create();
    axis = vec3.create();
    vec3.normalize(axis, vec3.fromValues(1.0, 0.0, 1.0));
    mat4.translate(model, model, vec3.fromValues(-1.0, 0.0, 2.0));
    mat4.rotate(model, model, Math.PI / 3, axis);
    mat4.scale(model, model, vec3.fromValues(0.25, 0.25, 0.25));
    gl.uniformMatrix4fv(gl.getUniformLocation(shader.programId, "model"), false, model);
    renderCube();
}

function renderCube() {
    if (!cubeVAO) {
        let vertices = new Float32Array([
            // back face
            -1.0, -1.0, -1.0, 0.0, 0.0, -1.0, 0.0, 0.0, // bottom-left
            1.0, 1.0, -1.0, 0.0, 0.0, -1.0, 1.0, 1.0, // top-right
            1.0, -1.0, -1.0, 0.0, 0.0, -1.0, 1.0, 0.0, // bottom-right         
            1.0, 1.0, -1.0, 0.0, 0.0, -1.0, 1.0, 1.0, // top-right
            -1.0, -1.0, -1.0, 0.0, 0.0, -1.0, 0.0, 0.0, // bottom-left
            -1.0, 1.0, -1.0, 0.0, 0.0, -1.0, 0.0, 1.0, // top-left
            // front face
            -1.0, -1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, // bottom-left
            1.0, -1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, // bottom-right
            1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, // top-right
            1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, // top-right
            -1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, // top-left
            -1.0, -1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, // bottom-left
            // left face
            -1.0, 1.0, 1.0, -1.0, 0.0, 0.0, 1.0, 0.0, // top-right
            -1.0, 1.0, -1.0, -1.0, 0.0, 0.0, 1.0, 1.0, // top-left
            -1.0, -1.0, -1.0, -1.0, 0.0, 0.0, 0.0, 1.0, // bottom-left
            -1.0, -1.0, -1.0, -1.0, 0.0, 0.0, 0.0, 1.0, // bottom-left
            -1.0, -1.0, 1.0, -1.0, 0.0, 0.0, 0.0, 0.0, // bottom-right
            -1.0, 1.0, 1.0, -1.0, 0.0, 0.0, 1.0, 0.0, // top-right
            // right face
            1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, // top-left
            1.0, -1.0, -1.0, 1.0, 0.0, 0.0, 0.0, 1.0, // bottom-right
            1.0, 1.0, -1.0, 1.0, 0.0, 0.0, 1.0, 1.0, // top-right         
            1.0, -1.0, -1.0, 1.0, 0.0, 0.0, 0.0, 1.0, // bottom-right
            1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, // top-left
            1.0, -1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, // bottom-left     
            // bottom face
            -1.0, -1.0, -1.0, 0.0, -1.0, 0.0, 0.0, 1.0, // top-right
            1.0, -1.0, -1.0, 0.0, -1.0, 0.0, 1.0, 1.0, // top-left
            1.0, -1.0, 1.0, 0.0, -1.0, 0.0, 1.0, 0.0, // bottom-left
            1.0, -1.0, 1.0, 0.0, -1.0, 0.0, 1.0, 0.0, // bottom-left
            -1.0, -1.0, 1.0, 0.0, -1.0, 0.0, 0.0, 0.0, // bottom-right
            -1.0, -1.0, -1.0, 0.0, -1.0, 0.0, 0.0, 1.0, // top-right
            // top face
            -1.0, 1.0, -1.0, 0.0, 1.0, 0.0, 0.0, 1.0, // top-left
            1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, // bottom-right
            1.0, 1.0, -1.0, 0.0, 1.0, 0.0, 1.0, 1.0, // top-right     
            1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, // bottom-right
            -1.0, 1.0, -1.0, 0.0, 1.0, 0.0, 0.0, 1.0, // top-left
            -1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0  // bottom-left
        ])
        cubeVAO = gl.createVertexArray();
        cubeVBO = gl.createBuffer();
        // fill buffer
        gl.bindBuffer(gl.ARRAY_BUFFER, cubeVBO);
        gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
        // link vertex attributes
        gl.bindVertexArray(cubeVAO);
        gl.enableVertexAttribArray(0);
        gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 8 * sizeFloat, 0);
        gl.enableVertexAttribArray(1);
        gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 8 * sizeFloat, 3 * sizeFloat);
        gl.enableVertexAttribArray(2);
        gl.vertexAttribPointer(2, 2, gl.FLOAT, false, 8 * sizeFloat, 6 * sizeFloat);
        gl.bindBuffer(gl.ARRAY_BUFFER, null);
        gl.bindVertexArray(null);
    }
    // render Cube
    gl.bindVertexArray(cubeVAO);
    gl.drawArrays(gl.TRIANGLES, 0, 36);
    gl.bindVertexArray(null);
}

// renderQuad() renders a 1x1 XY quad in NDC
// -----------------------------------------
function renderQuad() {
    if (!quadVAO) {
        let quadVertices = new Float32Array([
            // positions    // texture Coords
            -1.0, 1.0, 0.0, 0.0, 1.0,
            -1.0, -1.0, 0.0, 0.0, 0.0,
            1.0, 1.0, 0.0, 1.0, 1.0,
            1.0, -1.0, 0.0, 1.0, 0.0,
        ]);
        // setup plane VAO
        quadVAO = gl.createVertexArray();
        quadVBO = gl.createBuffer();
        gl.bindVertexArray(quadVAO);
        gl.bindBuffer(gl.ARRAY_BUFFER, quadVBO);
        gl.bufferData(gl.ARRAY_BUFFER, quadVertices, gl.STATIC_DRAW);
        gl.enableVertexAttribArray(0);
        gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 5 * sizeFloat, 0);
        gl.enableVertexAttribArray(1);
        gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 5 * sizeFloat, 3 * sizeFloat);
    }
    gl.bindVertexArray(quadVAO);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    gl.bindVertexArray(null);
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
function processInput() {
    const GLFW_PRESS = true;
    if (keyInput.isDown(GLFW_KEY_W) == GLFW_PRESS)
        camera.ProcessKeyboard(CameraMovement.FORWARD, deltaTime * 20);
    if (keyInput.isDown(GLFW_KEY_S) == GLFW_PRESS)
        camera.ProcessKeyboard(CameraMovement.BACKWARD, deltaTime * 20);
    if (keyInput.isDown(GLFW_KEY_A) == GLFW_PRESS)
        camera.ProcessKeyboard(CameraMovement.LEFT, deltaTime * 20);
    if (keyInput.isDown(GLFW_KEY_D) == GLFW_PRESS)
        camera.ProcessKeyboard(CameraMovement.RIGHT, deltaTime * 20);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
function mouse_move_callback(xoffset, yoffset, buttonID) {
    if (buttonID == 1)
        camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
function mouse_scroll_callback(yoffset) {
    camera.ProcessMouseScroll(yoffset);
}

// utility function for loading a 2D texture from file
// ---------------------------------------------------
function loadTexture(url, nrComponents, gammaCorrection) {
    const textureID = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, textureID);

    const level = 0;
    const srcType = gl.UNSIGNED_BYTE;
    const pixel = new Uint8Array([0, 0, 255, 255]);
    gl.texImage2D(gl.TEXTURE_2D, level, gl.RGBA, 1, 1, 0, gl.RGBA, srcType, pixel);

    const image = new Image();
    image.onload = function () {
        let internalFormat;
        let dataFormat;

        if (nrComponents == 1) {
            internalFormat = dataFormat = gl.RED;
        }
        else if (nrComponents == 3) {
            internalFormat = gammaCorrection ? gl.SRGB : gl.RGB;
            dataFormat = gl.RGB;
        }
        else if (nrComponents == 4) {
            internalFormat = gammaCorrection ? gl.SRGB8_ALPHA8 : gl.RGBA8;
            dataFormat = gl.RGBA;
        }

        gl.bindTexture(gl.TEXTURE_2D, textureID);
        gl.texImage2D(gl.TEXTURE_2D, 0, internalFormat, image.naturalWidth, image.naturalHeight, 0, dataFormat, gl.UNSIGNED_BYTE, image);
        gl.generateMipmap(gl.TEXTURE_2D);

        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    };
    image.src = url;

    return textureID;
}
