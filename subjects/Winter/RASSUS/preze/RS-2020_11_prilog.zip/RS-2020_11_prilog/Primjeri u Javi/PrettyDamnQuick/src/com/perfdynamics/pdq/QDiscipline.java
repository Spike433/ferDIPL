/*
 * Created on 17/02/2004
 *
 */
package com.perfdynamics.pdq;

/**
 * @author plh
 *
 */
public class QDiscipline {
    // Queueing disciplines

    public static final int ISRV = 6;  // Infinite server
    public static final int FCFS = 7;  // First-come first-serve
    public static final int PSHR = 8;  // Processor sharing
    public static final int LCFS = 9;  // Last-come first-serve

    public static void main(String[] args) {
    }
}
