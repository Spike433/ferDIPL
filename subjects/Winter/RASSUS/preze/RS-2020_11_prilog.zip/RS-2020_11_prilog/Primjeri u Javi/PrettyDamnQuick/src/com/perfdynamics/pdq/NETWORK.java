/*
 * Created on 17/02/2004
 *
 */
package com.perfdynamics.pdq;

/**
 * Queueing Network Type
 *
 */
public class NETWORK {
    // Queueing Network Type

    public static final int VOID = -1;
    public static final int OPEN = 0;
    public static final int CLOSED = 1;
}  // Class NETWORK
