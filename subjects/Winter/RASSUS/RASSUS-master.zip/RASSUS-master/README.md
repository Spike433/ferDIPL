# [Raspodijeljeni sustavi](https://www.github.com/studosi-fer/RASSUS)
[<- Stranica predmeta](https://www.fer.unizg.hr/predmet/rassus)

[<- Povratak na listu predmeta](https://www.github.com/studosi/FER)