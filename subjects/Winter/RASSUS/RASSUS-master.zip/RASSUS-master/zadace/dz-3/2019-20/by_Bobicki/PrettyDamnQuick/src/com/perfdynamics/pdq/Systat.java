/*
 * Created on 17/02/2004
 *
 */
package com.perfdynamics.pdq;

/**
 * @author plh
 *
 */
public class Systat {

    public double response = 0.0;
    public double thruput = 0.0;
    public double residency = 0.0;
    public double physmem = 0.0;
    public double highwater = 0.0;
    public double malloc = 0.0;
    public double mpl = 0.0;
    public double maxN = 0.0;
    public double maxTP = 0.0;
    public double minRT = 0.0;

    public static void main(String[] args) {
    }
}
