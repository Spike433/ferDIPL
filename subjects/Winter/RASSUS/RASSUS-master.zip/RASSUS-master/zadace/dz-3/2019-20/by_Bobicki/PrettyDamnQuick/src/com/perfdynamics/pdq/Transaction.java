/*
 * Created on 17/02/2004
 *
 */
package com.perfdynamics.pdq;

/**
 * @author plh
 *
 */
public class Transaction {

    public String name;
    public double arrival_rate;
    public double saturation_rate;
    public Systat sys = null;
}  // Class Transaction
