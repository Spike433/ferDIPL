/*
 * Created on 17/02/2004
 *
 */
package com.perfdynamics.pdq;

/**
 * @author plh
 *
 */
public class Terminal {

    public String name = null;
    public double population = 0.0;
    public double think = 0.0;
    public Systat sys = null;
}  // Class Terminal
