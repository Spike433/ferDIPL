/*
 * Created on 17/02/2004
 *
 */
package com.perfdynamics.pdq;

/**
 * Solution methods
 *
 */
public class Methods {
    // Solution methods

    public static final int EXACT = 13;
    public static final int APPROX = 14;
    public static final int CANON = 15;
}  // Class Methods
