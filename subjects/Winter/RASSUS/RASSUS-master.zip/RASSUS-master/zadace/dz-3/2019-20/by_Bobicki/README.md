Ostvareno bodova: 1/5*

*Sve napisano je točno, ali labos je nosio samo 1 bod, dok je zadatak uživo na obrani nosio preostala 4 boda (ili 0 ako ga se nije riješilo potpuno točno).