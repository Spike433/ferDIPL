ghc --make Client.hs -o client -O2 -threaded
ghc --make Server.hs -o server -O2 -threaded
