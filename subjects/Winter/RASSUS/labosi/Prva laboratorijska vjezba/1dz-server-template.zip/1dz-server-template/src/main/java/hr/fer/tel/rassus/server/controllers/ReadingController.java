package hr.fer.tel.rassus.server.controllers;


public class ReadingController {

  // TODO 4.3  Spremanje očitanja pojedinog senzora

  // TODO 4.5  Popis očitanja pojedinog senzora

}