package hr.fer.tel.rassus.server.services;

public interface SensorRepository {
  //  TODO
}
