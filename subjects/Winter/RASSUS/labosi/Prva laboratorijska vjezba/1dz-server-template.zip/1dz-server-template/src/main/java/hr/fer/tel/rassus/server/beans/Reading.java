package hr.fer.tel.rassus.server.beans;

public class Reading {
  //  TODO

}

