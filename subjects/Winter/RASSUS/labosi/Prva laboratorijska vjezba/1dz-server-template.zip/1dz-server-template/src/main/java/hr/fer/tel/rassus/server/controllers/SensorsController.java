package hr.fer.tel.rassus.server.controllers;


public class SensorsController {

    //  TODO 4.1  Registracija

    //  TODO 4.4  Popis senzora

    //  TODO 4.2  Najbliži susjed

}
