"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/register";
exports.ids = ["pages/api/register"];
exports.modules = {

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ "(api)/./pages/api/register.ts":
/*!*******************************!*\
  !*** ./pages/api/register.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @prisma/client */ \"@prisma/client\");\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);\n\nconst prisma = new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient();\nconst validate = (req)=>{\n    return {\n        latitude: parseFloat(req.body.latitude || \"\"),\n        longitude: parseFloat(req.body.longitude || \"\"),\n        ip: req.body.ip || \"\",\n        port: parseInt(req.body.port || \"\")\n    };\n};\nasync function handler(req, res) {\n    const sensorInput = validate(req);\n    const sensor = await prisma.sensor.create({\n        data: sensorInput\n    });\n    res.status(201).json(sensor);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvcmVnaXN0ZXIudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRThDO0FBRTlDLE1BQU1DLFNBQVMsSUFBSUQsd0RBQVlBO0FBRS9CLE1BQU1FLFdBQVcsQ0FBQ0MsTUFBcUM7SUFDckQsT0FBTztRQUNMQyxVQUFVQyxXQUFXLElBQUtDLElBQUksQ0FBQ0YsUUFBUSxJQUFlO1FBQ3RERyxXQUFXRixXQUFXLElBQUtDLElBQUksQ0FBQ0MsU0FBUyxJQUFlO1FBQ3hEQyxJQUFJLElBQUtGLElBQUksQ0FBQ0UsRUFBRSxJQUFlO1FBQy9CQyxNQUFNQyxTQUFTLElBQUtKLElBQUksQ0FBQ0csSUFBSSxJQUFlO0lBQzlDO0FBQ0Y7QUFFZSxlQUFlRSxRQUM1QlIsR0FBbUIsRUFDbkJTLEdBQTRCLEVBQzVCO0lBQ0EsTUFBTUMsY0FBY1gsU0FBU0M7SUFFN0IsTUFBTVcsU0FBUyxNQUFNYixPQUFPYSxNQUFNLENBQUNDLE1BQU0sQ0FBQztRQUN4Q0MsTUFBTUg7SUFDUjtJQUVBRCxJQUFJSyxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDSjtBQUN2QixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc2VydmVyLy4vcGFnZXMvYXBpL3JlZ2lzdGVyLnRzPzdkYTQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBOZXh0QXBpUmVxdWVzdCwgTmV4dEFwaVJlc3BvbnNlIH0gZnJvbSBcIm5leHRcIjtcbmltcG9ydCB7IFNlbnNvciwgU2Vuc29ySW5wdXQgfSBmcm9tIFwiLi4vLi4vaW50ZXJmYWNlc1wiO1xuaW1wb3J0IHsgUHJpc21hQ2xpZW50IH0gZnJvbSBcIkBwcmlzbWEvY2xpZW50XCI7XG5cbmNvbnN0IHByaXNtYSA9IG5ldyBQcmlzbWFDbGllbnQoKTtcblxuY29uc3QgdmFsaWRhdGUgPSAocmVxOiBOZXh0QXBpUmVxdWVzdCk6IFNlbnNvcklucHV0ID0+IHtcbiAgcmV0dXJuIHtcbiAgICBsYXRpdHVkZTogcGFyc2VGbG9hdCgocmVxLmJvZHkubGF0aXR1ZGUgYXMgc3RyaW5nKSB8fCBcIlwiKSxcbiAgICBsb25naXR1ZGU6IHBhcnNlRmxvYXQoKHJlcS5ib2R5LmxvbmdpdHVkZSBhcyBzdHJpbmcpIHx8IFwiXCIpLFxuICAgIGlwOiAocmVxLmJvZHkuaXAgYXMgc3RyaW5nKSB8fCBcIlwiLFxuICAgIHBvcnQ6IHBhcnNlSW50KChyZXEuYm9keS5wb3J0IGFzIHN0cmluZykgfHwgXCJcIiksXG4gIH07XG59O1xuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBoYW5kbGVyKFxuICByZXE6IE5leHRBcGlSZXF1ZXN0LFxuICByZXM6IE5leHRBcGlSZXNwb25zZTxTZW5zb3I+XG4pIHtcbiAgY29uc3Qgc2Vuc29ySW5wdXQgPSB2YWxpZGF0ZShyZXEpO1xuXG4gIGNvbnN0IHNlbnNvciA9IGF3YWl0IHByaXNtYS5zZW5zb3IuY3JlYXRlKHtcbiAgICBkYXRhOiBzZW5zb3JJbnB1dCxcbiAgfSk7XG5cbiAgcmVzLnN0YXR1cygyMDEpLmpzb24oc2Vuc29yKTtcbn1cbiJdLCJuYW1lcyI6WyJQcmlzbWFDbGllbnQiLCJwcmlzbWEiLCJ2YWxpZGF0ZSIsInJlcSIsImxhdGl0dWRlIiwicGFyc2VGbG9hdCIsImJvZHkiLCJsb25naXR1ZGUiLCJpcCIsInBvcnQiLCJwYXJzZUludCIsImhhbmRsZXIiLCJyZXMiLCJzZW5zb3JJbnB1dCIsInNlbnNvciIsImNyZWF0ZSIsImRhdGEiLCJzdGF0dXMiLCJqc29uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/register.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/register.ts"));
module.exports = __webpack_exports__;

})();