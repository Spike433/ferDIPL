"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/measurement";
exports.ids = ["pages/api/measurement"];
exports.modules = {

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ "(api)/./pages/api/measurement.ts":
/*!**********************************!*\
  !*** ./pages/api/measurement.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @prisma/client */ \"@prisma/client\");\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);\n\nconst prisma = new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient();\nconst validate = (req)=>{\n    return {\n        temperature: parseFloat(req.body.temperature || \"\"),\n        pressure: parseFloat(req.body.pressure || \"\"),\n        humidity: parseFloat(req.body.humidity || \"\"),\n        co: parseFloat(req.body.co || \"\"),\n        no2: parseFloat(req.body.no2 || \"\"),\n        so2: parseFloat(req.body.so2 || \"\")\n    };\n};\nasync function handler(req, res) {\n    const readingInput = validate(req);\n    const sensorId = parseInt(req.body.sensorId || \"\");\n    const sensor = await prisma.sensor.findFirst({\n        where: {\n            id: sensorId\n        }\n    });\n    if (sensor == undefined) {\n        res.status(204).json({\n            id: 0,\n            temperature: null,\n            pressure: null,\n            humidity: null,\n            co: null,\n            no2: null,\n            so2: null\n        });\n        return;\n    }\n    const reading = await prisma.reading.create({\n        data: {\n            ...readingInput,\n            sensorId: parseInt(req.body.sensorId || \"\")\n        }\n    });\n    res.status(201).json(reading);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvbWVhc3VyZW1lbnQudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQzhDO0FBRzlDLE1BQU1DLFNBQVMsSUFBSUQsd0RBQVlBO0FBRS9CLE1BQU1FLFdBQVcsQ0FBQ0MsTUFBc0M7SUFDdEQsT0FBTztRQUNMQyxhQUFhQyxXQUFXLElBQUtDLElBQUksQ0FBQ0YsV0FBVyxJQUFlO1FBQzVERyxVQUFVRixXQUFXLElBQUtDLElBQUksQ0FBQ0MsUUFBUSxJQUFlO1FBQ3REQyxVQUFVSCxXQUFXLElBQUtDLElBQUksQ0FBQ0UsUUFBUSxJQUFlO1FBQ3REQyxJQUFJSixXQUFXLElBQUtDLElBQUksQ0FBQ0csRUFBRSxJQUFlO1FBQzFDQyxLQUFLTCxXQUFXLElBQUtDLElBQUksQ0FBQ0ksR0FBRyxJQUFlO1FBQzVDQyxLQUFLTixXQUFXLElBQUtDLElBQUksQ0FBQ0ssR0FBRyxJQUFlO0lBQzlDO0FBQ0Y7QUFFZSxlQUFlQyxRQUM1QlQsR0FBbUIsRUFDbkJVLEdBQTZCLEVBQzdCO0lBQ0EsTUFBTUMsZUFBZVosU0FBU0M7SUFDOUIsTUFBTVksV0FBV0MsU0FBUyxJQUFLVixJQUFJLENBQUNTLFFBQVEsSUFBZTtJQUUzRCxNQUFNRSxTQUFTLE1BQU1oQixPQUFPZ0IsTUFBTSxDQUFDQyxTQUFTLENBQUM7UUFDM0NDLE9BQU87WUFBRUMsSUFBSUw7UUFBUztJQUN4QjtJQUVBLElBQUlFLFVBQVVJLFdBQVc7UUFDdkJSLElBQUlTLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7WUFDbkJILElBQUk7WUFDSmhCLGFBQWEsSUFBSTtZQUNqQkcsVUFBVSxJQUFJO1lBQ2RDLFVBQVUsSUFBSTtZQUNkQyxJQUFJLElBQUk7WUFDUkMsS0FBSyxJQUFJO1lBQ1RDLEtBQUssSUFBSTtRQUNYO1FBQ0E7SUFDRixDQUFDO0lBRUQsTUFBTWEsVUFBVSxNQUFNdkIsT0FBT3VCLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDO1FBQzFDQyxNQUFNO1lBQ0osR0FBR1osWUFBWTtZQUNmQyxVQUFVQyxTQUFTLElBQUtWLElBQUksQ0FBQ1MsUUFBUSxJQUFlO1FBQ3REO0lBQ0Y7SUFFQUYsSUFBSVMsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQ0M7QUFDdkIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3NlcnZlci8uL3BhZ2VzL2FwaS9tZWFzdXJlbWVudC50cz8yNzlkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTmV4dEFwaVJlcXVlc3QsIE5leHRBcGlSZXNwb25zZSB9IGZyb20gXCJuZXh0XCI7XG5pbXBvcnQgeyBQcmlzbWFDbGllbnQgfSBmcm9tIFwiQHByaXNtYS9jbGllbnRcIjtcbmltcG9ydCB7IFJlYWRpbmcsIFJlYWRpbmdJbnB1dCB9IGZyb20gXCIuLi8uLi9pbnRlcmZhY2VzXCI7XG5cbmNvbnN0IHByaXNtYSA9IG5ldyBQcmlzbWFDbGllbnQoKTtcblxuY29uc3QgdmFsaWRhdGUgPSAocmVxOiBOZXh0QXBpUmVxdWVzdCk6IFJlYWRpbmdJbnB1dCA9PiB7XG4gIHJldHVybiB7XG4gICAgdGVtcGVyYXR1cmU6IHBhcnNlRmxvYXQoKHJlcS5ib2R5LnRlbXBlcmF0dXJlIGFzIHN0cmluZykgfHwgXCJcIiksXG4gICAgcHJlc3N1cmU6IHBhcnNlRmxvYXQoKHJlcS5ib2R5LnByZXNzdXJlIGFzIHN0cmluZykgfHwgXCJcIiksXG4gICAgaHVtaWRpdHk6IHBhcnNlRmxvYXQoKHJlcS5ib2R5Lmh1bWlkaXR5IGFzIHN0cmluZykgfHwgXCJcIiksXG4gICAgY286IHBhcnNlRmxvYXQoKHJlcS5ib2R5LmNvIGFzIHN0cmluZykgfHwgXCJcIiksXG4gICAgbm8yOiBwYXJzZUZsb2F0KChyZXEuYm9keS5ubzIgYXMgc3RyaW5nKSB8fCBcIlwiKSxcbiAgICBzbzI6IHBhcnNlRmxvYXQoKHJlcS5ib2R5LnNvMiBhcyBzdHJpbmcpIHx8IFwiXCIpLFxuICB9O1xufTtcblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihcbiAgcmVxOiBOZXh0QXBpUmVxdWVzdCxcbiAgcmVzOiBOZXh0QXBpUmVzcG9uc2U8UmVhZGluZz5cbikge1xuICBjb25zdCByZWFkaW5nSW5wdXQgPSB2YWxpZGF0ZShyZXEpO1xuICBjb25zdCBzZW5zb3JJZCA9IHBhcnNlSW50KChyZXEuYm9keS5zZW5zb3JJZCBhcyBzdHJpbmcpIHx8IFwiXCIpO1xuXG4gIGNvbnN0IHNlbnNvciA9IGF3YWl0IHByaXNtYS5zZW5zb3IuZmluZEZpcnN0KHtcbiAgICB3aGVyZTogeyBpZDogc2Vuc29ySWQgfSxcbiAgfSk7XG5cbiAgaWYgKHNlbnNvciA9PSB1bmRlZmluZWQpIHtcbiAgICByZXMuc3RhdHVzKDIwNCkuanNvbih7XG4gICAgICBpZDogMCxcbiAgICAgIHRlbXBlcmF0dXJlOiBudWxsLFxuICAgICAgcHJlc3N1cmU6IG51bGwsXG4gICAgICBodW1pZGl0eTogbnVsbCxcbiAgICAgIGNvOiBudWxsLFxuICAgICAgbm8yOiBudWxsLFxuICAgICAgc28yOiBudWxsLFxuICAgIH0pO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IHJlYWRpbmcgPSBhd2FpdCBwcmlzbWEucmVhZGluZy5jcmVhdGUoe1xuICAgIGRhdGE6IHtcbiAgICAgIC4uLnJlYWRpbmdJbnB1dCxcbiAgICAgIHNlbnNvcklkOiBwYXJzZUludCgocmVxLmJvZHkuc2Vuc29ySWQgYXMgc3RyaW5nKSB8fCBcIlwiKSxcbiAgICB9LFxuICB9KTtcblxuICByZXMuc3RhdHVzKDIwMSkuanNvbihyZWFkaW5nKTtcbn1cbiJdLCJuYW1lcyI6WyJQcmlzbWFDbGllbnQiLCJwcmlzbWEiLCJ2YWxpZGF0ZSIsInJlcSIsInRlbXBlcmF0dXJlIiwicGFyc2VGbG9hdCIsImJvZHkiLCJwcmVzc3VyZSIsImh1bWlkaXR5IiwiY28iLCJubzIiLCJzbzIiLCJoYW5kbGVyIiwicmVzIiwicmVhZGluZ0lucHV0Iiwic2Vuc29ySWQiLCJwYXJzZUludCIsInNlbnNvciIsImZpbmRGaXJzdCIsIndoZXJlIiwiaWQiLCJ1bmRlZmluZWQiLCJzdGF0dXMiLCJqc29uIiwicmVhZGluZyIsImNyZWF0ZSIsImRhdGEiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/measurement.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/measurement.ts"));
module.exports = __webpack_exports__;

})();