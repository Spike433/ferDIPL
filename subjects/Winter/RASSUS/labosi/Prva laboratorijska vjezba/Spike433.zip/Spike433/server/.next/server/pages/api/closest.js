"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/closest";
exports.ids = ["pages/api/closest"];
exports.modules = {

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ "(api)/./pages/api/closest.ts":
/*!******************************!*\
  !*** ./pages/api/closest.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @prisma/client */ \"@prisma/client\");\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);\n\nconst prisma = new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient();\nasync function handler(req, res) {\n    const id = parseInt(req.body.id || \"\");\n    const sensors = await prisma.sensor.findMany();\n    const sensor = await prisma.sensor.findFirst({\n        where: {\n            id: id\n        }\n    });\n    if (sensor == undefined) {\n        res.status(204).json({\n            latitude: 0,\n            longitude: 0,\n            ip: \"\",\n            port: 0\n        });\n        return;\n    }\n    const closest = sensors.filter((s)=>s.id != id).map((s)=>{\n        const dlon = sensor.longitude - s.longitude;\n        const dlat = sensor.latitude - s.latitude;\n        const a = Math.sin(dlat / 2) ** 2 + Math.cos(sensor.latitude) * Math.cos(s.latitude) * Math.sin(dlon / 2) ** 2;\n        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));\n        const d = 6371 * c;\n        return {\n            ...s,\n            distance: d\n        };\n    }).sort((a, b)=>a.distance - b.distance)[0];\n    if (closest == undefined) {\n        res.status(204).json(closest);\n        return;\n    }\n    res.status(200).json(closest);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvY2xvc2VzdC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFDOEM7QUFHOUMsTUFBTUMsU0FBUyxJQUFJRCx3REFBWUE7QUFFaEIsZUFBZUUsUUFDNUJDLEdBQW1CLEVBQ25CQyxHQUFpQyxFQUNqQztJQUNBLE1BQU1DLEtBQUtDLFNBQVMsSUFBS0MsSUFBSSxDQUFDRixFQUFFLElBQWU7SUFFL0MsTUFBTUcsVUFBVSxNQUFNUCxPQUFPUSxNQUFNLENBQUNDLFFBQVE7SUFFNUMsTUFBTUQsU0FBUyxNQUFNUixPQUFPUSxNQUFNLENBQUNFLFNBQVMsQ0FBQztRQUMzQ0MsT0FBTztZQUFFUCxJQUFJQTtRQUFHO0lBQ2xCO0lBRUEsSUFBSUksVUFBVUksV0FBVztRQUN2QlQsSUFBSVUsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztZQUNuQkMsVUFBVTtZQUNWQyxXQUFXO1lBQ1hDLElBQUk7WUFDSkMsTUFBTTtRQUNSO1FBQ0E7SUFDRixDQUFDO0lBRUQsTUFBTUMsVUFBVVosUUFDYmEsTUFBTSxDQUFDLENBQUNDLElBQU1BLEVBQUVqQixFQUFFLElBQUlBLElBQ3RCa0IsR0FBRyxDQUFDLENBQUNELElBQU07UUFDVixNQUFNRSxPQUFPZixPQUFPUSxTQUFTLEdBQUdLLEVBQUVMLFNBQVM7UUFDM0MsTUFBTVEsT0FBT2hCLE9BQU9PLFFBQVEsR0FBR00sRUFBRU4sUUFBUTtRQUN6QyxNQUFNVSxJQUNKQyxLQUFLQyxHQUFHLENBQUNILE9BQU8sTUFBTSxJQUN0QkUsS0FBS0UsR0FBRyxDQUFDcEIsT0FBT08sUUFBUSxJQUN0QlcsS0FBS0UsR0FBRyxDQUFDUCxFQUFFTixRQUFRLElBQ25CVyxLQUFLQyxHQUFHLENBQUNKLE9BQU8sTUFBTTtRQUMxQixNQUFNTSxJQUFJLElBQUlILEtBQUtJLEtBQUssQ0FBQ0osS0FBS0ssSUFBSSxDQUFDTixJQUFJQyxLQUFLSyxJQUFJLENBQUMsSUFBSU47UUFDckQsTUFBTU8sSUFBSSxPQUFPSDtRQUVqQixPQUFPO1lBQ0wsR0FBR1IsQ0FBQztZQUNKWSxVQUFVRDtRQUNaO0lBQ0YsR0FDQ0UsSUFBSSxDQUFDLENBQUNULEdBQUdVLElBQU1WLEVBQUVRLFFBQVEsR0FBR0UsRUFBRUYsUUFBUSxDQUFDLENBQUMsRUFBRTtJQUU3QyxJQUFJZCxXQUFXUCxXQUFXO1FBQ3hCVCxJQUFJVSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDSztRQUNyQjtJQUNGLENBQUM7SUFFRGhCLElBQUlVLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUNLO0FBQ3ZCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zZXJ2ZXIvLi9wYWdlcy9hcGkvY2xvc2VzdC50cz9kY2RkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTmV4dEFwaVJlcXVlc3QsIE5leHRBcGlSZXNwb25zZSB9IGZyb20gXCJuZXh0XCI7XG5pbXBvcnQgeyBQcmlzbWFDbGllbnQgfSBmcm9tIFwiQHByaXNtYS9jbGllbnRcIjtcbmltcG9ydCB7IFNlbnNvcklucHV0IH0gZnJvbSBcIi4uLy4uL2ludGVyZmFjZXNcIjtcblxuY29uc3QgcHJpc21hID0gbmV3IFByaXNtYUNsaWVudCgpO1xuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBoYW5kbGVyKFxuICByZXE6IE5leHRBcGlSZXF1ZXN0LFxuICByZXM6IE5leHRBcGlSZXNwb25zZTxTZW5zb3JJbnB1dD5cbikge1xuICBjb25zdCBpZCA9IHBhcnNlSW50KChyZXEuYm9keS5pZCBhcyBzdHJpbmcpIHx8IFwiXCIpO1xuXG4gIGNvbnN0IHNlbnNvcnMgPSBhd2FpdCBwcmlzbWEuc2Vuc29yLmZpbmRNYW55KCk7XG5cbiAgY29uc3Qgc2Vuc29yID0gYXdhaXQgcHJpc21hLnNlbnNvci5maW5kRmlyc3Qoe1xuICAgIHdoZXJlOiB7IGlkOiBpZCB9LFxuICB9KTtcblxuICBpZiAoc2Vuc29yID09IHVuZGVmaW5lZCkge1xuICAgIHJlcy5zdGF0dXMoMjA0KS5qc29uKHtcbiAgICAgIGxhdGl0dWRlOiAwLFxuICAgICAgbG9uZ2l0dWRlOiAwLFxuICAgICAgaXA6IFwiXCIsXG4gICAgICBwb3J0OiAwLFxuICAgIH0pO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IGNsb3Nlc3QgPSBzZW5zb3JzXG4gICAgLmZpbHRlcigocykgPT4gcy5pZCAhPSBpZClcbiAgICAubWFwKChzKSA9PiB7XG4gICAgICBjb25zdCBkbG9uID0gc2Vuc29yLmxvbmdpdHVkZSAtIHMubG9uZ2l0dWRlO1xuICAgICAgY29uc3QgZGxhdCA9IHNlbnNvci5sYXRpdHVkZSAtIHMubGF0aXR1ZGU7XG4gICAgICBjb25zdCBhID1cbiAgICAgICAgTWF0aC5zaW4oZGxhdCAvIDIpICoqIDIgK1xuICAgICAgICBNYXRoLmNvcyhzZW5zb3IubGF0aXR1ZGUpICpcbiAgICAgICAgICBNYXRoLmNvcyhzLmxhdGl0dWRlKSAqXG4gICAgICAgICAgTWF0aC5zaW4oZGxvbiAvIDIpICoqIDI7XG4gICAgICBjb25zdCBjID0gMiAqIE1hdGguYXRhbjIoTWF0aC5zcXJ0KGEpLCBNYXRoLnNxcnQoMSAtIGEpKTtcbiAgICAgIGNvbnN0IGQgPSA2MzcxICogYztcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4ucyxcbiAgICAgICAgZGlzdGFuY2U6IGQsXG4gICAgICB9O1xuICAgIH0pXG4gICAgLnNvcnQoKGEsIGIpID0+IGEuZGlzdGFuY2UgLSBiLmRpc3RhbmNlKVswXTtcblxuICBpZiAoY2xvc2VzdCA9PSB1bmRlZmluZWQpIHtcbiAgICByZXMuc3RhdHVzKDIwNCkuanNvbihjbG9zZXN0KTtcbiAgICByZXR1cm47XG4gIH1cblxuICByZXMuc3RhdHVzKDIwMCkuanNvbihjbG9zZXN0KTtcbn1cbiJdLCJuYW1lcyI6WyJQcmlzbWFDbGllbnQiLCJwcmlzbWEiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwiaWQiLCJwYXJzZUludCIsImJvZHkiLCJzZW5zb3JzIiwic2Vuc29yIiwiZmluZE1hbnkiLCJmaW5kRmlyc3QiLCJ3aGVyZSIsInVuZGVmaW5lZCIsInN0YXR1cyIsImpzb24iLCJsYXRpdHVkZSIsImxvbmdpdHVkZSIsImlwIiwicG9ydCIsImNsb3Nlc3QiLCJmaWx0ZXIiLCJzIiwibWFwIiwiZGxvbiIsImRsYXQiLCJhIiwiTWF0aCIsInNpbiIsImNvcyIsImMiLCJhdGFuMiIsInNxcnQiLCJkIiwiZGlzdGFuY2UiLCJzb3J0IiwiYiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/closest.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/closest.ts"));
module.exports = __webpack_exports__;

})();