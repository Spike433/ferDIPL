# Install pacakages

inside Sensor and Node type yarn to install all pacakages

# Run

forgot how to exactly run Sensor and Node, try
yarn start Sensor
yarn start Node