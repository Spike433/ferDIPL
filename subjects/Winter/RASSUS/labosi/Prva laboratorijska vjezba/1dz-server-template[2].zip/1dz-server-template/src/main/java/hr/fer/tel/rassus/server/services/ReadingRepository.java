package hr.fer.tel.rassus.server.services;

public interface ReadingRepository {
  //  TODO
}
