clc
clear
syms d d1
T3 = [0 1 0 d; -1 0 0 0; 0 0 1 0; 0 0 0 1];
x = 0.07071;
TL1 = [x x 0 0; -x x 0 0; 0 0 1 0; 0 0 0 1];
TL0 = [1 0 0 0; 0 1 0 d1; 0 0 1 0; 0 0 0 1];

T4_njihovo = TL0*T3*TL1
T4_moje = T3*inv(TL1)*TL0