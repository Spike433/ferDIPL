import sys
#sys.path.append('/home/adrian/Desktop')
print(sys.path)

from helper_modules.pomocni import median

if __name__ == '__main__':
    x = median(9, 0, -5)
    print(x)
