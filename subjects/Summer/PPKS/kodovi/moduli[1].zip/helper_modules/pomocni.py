def median(x, y, z):
    return sorted([x, y, z])[1]

if __name__ == '__main__':
    print(median(0, 5, 3))
