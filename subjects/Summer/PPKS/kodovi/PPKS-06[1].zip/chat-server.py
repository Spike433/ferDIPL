import socket, threading, sys

connections = []

def handle_user(conn, addr):
    host, port = addr
    while True:
        msg = conn.recv(1024)
        if msg:
            print(f'{host}:{port} - {msg.decode()}')
            msg_to_send = f'From {host}:{port} - {msg.decode()}'
            for client_conn in connections:
                if client_conn != conn:
                    client_conn.send(msg_to_send.encode())
        else:
            conn.close()
            connections.remove(conn)
            break


if __name__ == "__main__":
    SERVER_ADDRESS = '127.0.0.1'
    LISTENING_PORT = int(sys.argv[1])

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((SERVER_ADDRESS, LISTENING_PORT))
    s.listen()

    print('Server running!')
    
    while True:
        conn, addr = s.accept()
        connections.append(conn)
        threading.Thread(target=handle_user, args=(conn, addr)).start()

    s.close()
