import socket
import time

HOST = "127.0.0.1"  # The server's hostname or IP address
PORT = 65432  # The port used by the server

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    for i in range(10):
        message = f'Hello {i}!'
        s.sendall(str.encode(message))
        data = s.recv(1024)
        time.sleep(1)
        print(f"Received {data!r}")
        #print(data.decode())
