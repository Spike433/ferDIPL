from multiprocessing import Process, Queue
from time import sleep

def f(q):
    sleep(1)
    q.put([42, None, 'hello'])

if __name__ == '__main__':
    q = Queue()
    p = Process(target=f, args=(q,))
    p.start()
    print('cekam...')
    print(q.get())    # prints "[42, None, 'hello']"
    p.join()
