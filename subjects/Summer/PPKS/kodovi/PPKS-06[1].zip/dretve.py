import threading
import time

# Code to execute in an independent thread
def countdown(n):
    while n > 0:
        print('t-minus: {}\n'.format(n))
        n -= 1
        time.sleep(1)

# Create and launch a thread
t = threading.Thread(target=countdown, args=(10,))
t.start()  # explicit start
t2 = threading.Thread(target=countdown, args=(10,))
# t.join()
t2.start()