import os
f = os.fork()
if f == 0:
    print(f'Child Process: PID {os.getpid()}, fork returned {f}')
else:
    print(f'Parent Process: PID {os.getpid()}, fork returned {f}')
