import threading
import queue

NUM_THREADS = 4

def worker(work_queue, results_queue):
    while True:
        item = work_queue.get()
        if item == 'DONE':
            break
        result = item ** 2
        results_queue.put(result)
        work_queue.task_done()

if __name__ == '__main__':
    work_queue = queue.Queue()
    results_queue = queue.Queue()

    threads = [
        threading.Thread(target=worker, args=(work_queue, results_queue))
        for i in range(NUM_THREADS)
    ]

    for thread in threads:
        thread.start()

    for i in range(1, 11):
        work_queue.put(i)

    work_queue.join()
    print('all items processed')

    for t in threads:
        work_queue.put("DONE")

    while threads:
        threads.pop().join()

    results = []
    while not results_queue.empty():
        results.append(results_queue.get())
    print(sorted(results))