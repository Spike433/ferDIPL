from multiprocessing import Pool

def suma_kvadrata(interval):
    a, b = interval
    return sum(x * x for x in range(a, b + 1))

if __name__ == '__main__':
    n = 10**7
    #print(suma_kvadrata((1, n)))
    with Pool(4) as p:
        argumenti = [(1, n//4),
                     (n//4 + 1, n//2),
                     (n//2 + 1, 3*n//4),
                     (3*n//4 + 1, n)]
        rezultati = p.map(suma_kvadrata, argumenti)
    print(sum(rezultati))
