import os
import threading
import queue
import urllib.request
import webbrowser

def dohvati(url, red):
    sadrzaj = urllib.request.urlopen(url).read()
    red.put(sadrzaj)

if __name__ == "__main__":
    red = queue.Queue()
    t1 = threading.Thread(target=dohvati, args=('https://google.com', red))
    t2 = threading.Thread(target=dohvati, args=('https://bing.com', red))
    t1.start()
    t2.start()
    sadrzaj = red.get()
    with open("stranica.html", "w") as f:
        f.write(str(sadrzaj))
    webbrowser.open("stranica.html")