import socket, threading, sys

def receive_messages(conn):
    while True:
        msg = conn.recv(1024)
        if msg:
            print(msg.decode())
        else:
            conn.close()
            break

if __name__ == "__main__":
    SERVER_ADDRESS = '127.0.0.1'
    SERVER_PORT = int(sys.argv[1])

    s = socket.socket()
    s.connect((SERVER_ADDRESS, SERVER_PORT))
    threading.Thread(target=receive_messages, args=(s,)).start()

    print('Connected to chat!')

    while True:
        msg = input()
        if msg == 'quit':
            break
        s.sendall(msg.encode())

    s.close()
