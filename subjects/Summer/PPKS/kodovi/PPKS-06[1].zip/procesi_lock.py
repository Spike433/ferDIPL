from multiprocessing import Process, Lock
from time import sleep

def f(lock, i):
    with lock:
        print()
        print('hello world')
        sleep(0.1)
        print(i)
        print()

if __name__ == '__main__':
    l = Lock()

    for num in range(10):
        Process(target=f, args=(l, num)).start()
