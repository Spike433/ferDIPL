from multiprocessing import Process, Queue
from time import sleep
from math import sin, cos

def racunaj(f, q):
    rezultat = sum(f(x) for x in range(1, 10**7 + 1))
    q.put((f, rezultat))

if __name__ == '__main__':
    q = Queue()
    p1 = Process(target=racunaj, args=(sin, q))
    p2 = Process(target=racunaj, args=(cos, q))
    p1.start()
    p2.start()
    print(q.get())
