package hr.fer.tel.ptm.examples;

/**
 *
 * @author lorena.kc
 */
public class Test {
    
    public static void methodA() {
        
        int[] a = new int[10];
        int[] b = new int[10];
        
        for (int i = 0; i < 10; i++)
            a[i] = 1;
        for (int i = 0; i < 10; i++)
            b[i] = 2;
        
    }
    
    public static void methodB() {
        
        int[] a = new int[10];
        int[] b = new int[10];
        
        for (int i = 0; i < 10; i++) {
            a[i] = 1;
            b[i] = 2;
        }
        
    }
    
    public static void main(String[] args) {
        
        methodA();
        methodB();
        
    }
}
