package hr.fer.tel.ptm.examples.datastructures;

/**
 *
 * @author lorena.kc
 */
public class AdvancedQuaternaryTree implements ItemContainer {

    private QuaternaryTree left;
    private QuaternaryTree cleft;
    private QuaternaryTree cright;
    private QuaternaryTree right;
    private Item content;
    private float leftBoundary;
    private float rightBoundary;
    private float hash;

    public AdvancedQuaternaryTree() {
    }

    public AdvancedQuaternaryTree(Item content) {
        this.content = content;
        this.hash = this.content.hashCode();
    }

    public ItemContainer add(Item item) {
        
        if (this.content == null) {
            // prvi
            this.content = item;
            return this;
        } else if (item.hashCode() < this.hash) {
            //treba ga stavit lijevo ili u sredinu
            this.addLC(item);
        } else {
            //treba ga staviti desno ili u sredinu
            this.addRC(item);
        }
        return this;
    }

    private void addLC(Item item) {
        if (this.left == null) {
            //stavi ga lijevo
            this.left = new QuaternaryTree(item);
        } else if (this.goesLeft(item)) {
            //dodaj ga niže lijevo
            this.left.add(item);
        } else if (this.cleft == null) {
            //stavi ga u sredinu
            this.cleft = new QuaternaryTree(item);
        } else {
            //dodaj ga niže u sredinu
            this.cleft.add(item);
        }
    }

    private boolean goesLeft(Item item) {
        if(leftBoundary == 0)
            this.leftBoundary = this.left.content.hashCode() + (this.content.hashCode() - this.left.content.hashCode())/2f;
        
        return item.hashCode() < this.leftBoundary;
    }

    private void addRC(Item item) {
        if (this.right == null) {
            //stavi ga desno
            this.right = new QuaternaryTree(item);
        } else if (this.goesRight(item)) {
            //dodaj ga niže desno
            this.right.add(item);
        } else if (this.cright == null) {
            //stavi ga u sredinu
            this.cright = new QuaternaryTree(item);
        } else {
            //dodaj ga niže u sredinu
            this.cright.add(item);
        }
    }

    private boolean goesRight(Item item) {
        
        if(this.rightBoundary == 0)
            this.rightBoundary = this.content.hashCode() + (this.right.content.hashCode() - this.content.hashCode())/2f;
        return item.hashCode() > this.rightBoundary;
    }

    public boolean contains(Item item) {
        if (this.content == null) {
            // prazno stablo
            return false;
        } else if (item.equals(this.content)) {
            // nađen je
            return true;
        } else if (item.hashCode() < this.hash) {
            //treba ga tražit lijevo ili u sredini
            return this.findLC(item);
        } else {
            //treba ga tražit desno ili u sredini
            return this.findRC(item);
        }
    }

    private boolean findLC(Item item) {
        if (this.left == null) {
            //nema ga lijevo
            return false;
        } else if (this.goesLeft(item)) {
            //traži ga niže lijevo
            return this.left.contains(item);
        } else if (this.cleft == null) {
            //nema ga u sredini
            return false;
        } else {
            //traži ga niže u sredini
            return this.cleft.contains(item);
        }
    }

    private boolean findRC(Item item) {
        if (this.right == null) {
            //nema ga desno
            return false;
        } else if (this.goesRight(item)) {
            //traži ga niže desno
            return this.right.contains(item);
        } else if (this.cright == null) {
            //nema ga u sredini
            return false;
        } else {
            //traži ga niže u sredini
            return this.cright.contains(item);
        }
    }
}