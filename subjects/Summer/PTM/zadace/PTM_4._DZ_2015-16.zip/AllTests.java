/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.fer.tel.ptm.examples;

import hr.fer.tel.ptm.examples.datastructures.AdvancedTernaryTree;
import hr.fer.tel.ptm.examples.datastructures.AdvancedQuaternaryTree;
import hr.fer.tel.ptm.examples.datastructures.BinaryTree;
import hr.fer.tel.ptm.examples.datastructures.TernaryTree;
import hr.fer.tel.ptm.examples.datastructures.QuaternaryTree;
import hr.fer.tel.ptm.examples.datastructures.SinglyLinkedList;
import hr.fer.tel.ptm.examples.datastructures.Item;
import hr.fer.tel.ptm.examples.datastructures.ItemContainer;
import java.util.Random;

/**
 *
 * @author lorena.kc
 */
public class AllTests {

    public static void main(String[] args) {

        ItemContainer binaryTree = new BinaryTree();
        ItemContainer ternaryTree =  new TernaryTree();
        ItemContainer quaternaryTree = new QuaternaryTree();
        ItemContainer singlyLinkedList = new SinglyLinkedList();
        ItemContainer advancedTernaryTree = new AdvancedTernaryTree();
        ItemContainer advancedQuaternaryTree = new AdvancedQuaternaryTree();

        //ukupni broj objekata
        final int N = 100000;
        Item[] items = new Item[N];

        //dodat ćemo 0 kao prvi objekt (zbog balansiranja)
        items[0] = new Item(0);

        Random random = new Random();
        for (int i = 1; i < N; i++) {
            //dohvati objekt kao nasumični cijeli broj u intervalu [-N,N]
            Item item = new Item(new Integer(random.nextInt(2 * N + 1)) - N);
            //dodaj objekte u polje (služi za kasnije traženje)
            items[i] = item;
        }

        for (int i = 0; i < N; i++) {
            //dodaj objekte u binarno stablo
            binaryTree = binaryTree.add(items[i]);
            ternaryTree = ternaryTree.add(items[i]);
            quaternaryTree = quaternaryTree.add(items[i]);
            singlyLinkedList = singlyLinkedList.add(items[i]);
            advancedTernaryTree = advancedTernaryTree.add(items[i]);
            advancedQuaternaryTree = advancedQuaternaryTree.add(items[i]);
            
        }
        
        System.out.println("Dodao sam " + fancyNum(N) + " u binarno stablo.");
        System.out.println("Dodao sam " + fancyNum(N) + " u ternarno stablo.");
        System.out.println("Dodao sam " + fancyNum(N) + " u kvaterarno stablo.");
        System.out.println("Dodao sam " + fancyNum(N) + " u linearnu listu.");
        //System.out.println("Dodao sam " + fancyNum(N) + " u poboljšano terarno stablo.");
        //System.out.println("Dodao sam " + fancyNum(N) + " u poboljšano kvaterarno stablo.");
        
        
        //potraži dodane objekte
        int a = 0;
        int b = 0;
        int c = 0;
        int d = 0;
        int e = 0;
        int f = 0;
        
        for (int i = 0; i < N; i++) {
            if (binaryTree.contains(items[i])) {
                a++;
            }
            if (ternaryTree.contains(items[i])) {
                b++;
            }
            if (quaternaryTree.contains(items[i])) {
                c++;
            }
            if (singlyLinkedList.contains(items[i])) {
                d++;
            }
            if (advancedTernaryTree.contains(items[i])) {
                e++;
            }
            if (advancedQuaternaryTree.contains(items[i])) {
                f++;
            }
        }
        
        System.out.println("Pronašao sam " + fancyNum(a) + " u binarnom stablu.");
        System.out.println("Pronašao sam " + fancyNum(b) + " u ternarnom stablu.");
        System.out.println("Pronašao sam " + fancyNum(c) + " u kvaterarnom stablu.");
        System.out.println("Pronašao sam " + fancyNum(d) + " u linearnoj listi.");
        //System.out.println("Pronašao sam " + fancyNum(c) + " u poboljšanom terarnom stablu.");
        //System.out.println("Pronašao sam " + fancyNum(d) + " u poboljšanom kvaterarnom stablu.");
    }

    public static String fancyNum(int i) {
        int digit = i % 10;

        if (digit == 1) {
            return i + " objekt";
        } else if (digit >= 2 && digit <= 4) {
            return i + " objekta";
        } else {
            return i + " objekata";
        }
    }
}