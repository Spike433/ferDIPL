# [Pouzdanost telekomunikacijske mreže](https://www.github.com/studosi-fer/PTM)
[<- Stranica predmeta](https://www.fer.unizg.hr/predmet/ptm)

[<- Povratak na listu predmeta](https://www.github.com/studosi/FER)